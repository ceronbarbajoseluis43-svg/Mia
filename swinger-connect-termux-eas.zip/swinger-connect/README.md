# SwingerConnect v2 – App completa (18+)

Red social tipo Facebook orientada a encuentros swingers y lifestyle abierto.  
**Solo para mayores de 18 años.**

## Funcionalidades

- ✅ Registro / Login con verificación de edad 18+
- ✅ Perfiles editables (bio, preferencias, looking for, foto de perfil)
- ✅ Subir y compartir **fotos y videos**
- ✅ Feed de publicaciones con media
- ✅ Sistema de amigos (solicitudes, aceptar, rechazar)
- ✅ Mensajería privada con fotos/videos
- ✅ Eventos (crear, apuntarse, listar)
- ✅ Búsqueda de personas
- ✅ App móvil nativa (React Native + Expo) para Android e iOS
- ✅ Frontend web (React + Vite)

## Estructura

```
swinger-connect/
├── backend/          ← API Node.js + Express + Prisma
├── frontend/         ← Web (React)
├── mobile/           ← App Android/iOS (Expo)
└── README.md
```

## Arranque rápido

### 1. Backend
```bash
cd backend
npm install
npx prisma generate
npx prisma db push
npm run dev
```
API → http://localhost:4000

### 2. App móvil (Android)
1. Instala **Expo Go** desde Google Play
2. Configura tu IP en `mobile/src/services/api.js`
3. Ejecuta:
```bash
cd mobile
npm install
npx expo start
```
4. Escanea el QR con Expo Go (misma WiFi)

### 3. Web (opcional)
```bash
cd frontend
npm install
npm run dev
```

## Endpoints principales

| Método | Ruta | Descripción |
|--------|------|-------------|
| POST | /api/auth/register | Registro 18+ |
| POST | /api/auth/login | Login |
| GET/PUT | /api/users/me | Perfil |
| POST | /api/upload | Subir foto/video |
| POST | /api/posts | Crear publicación |
| GET | /api/posts/feed | Feed |
| POST | /api/friendships/request/:id | Agregar amigo |
| GET | /api/friendships | Lista de conexiones |
| POST | /api/messages | Enviar mensaje |
| GET | /api/messages | Conversaciones |
| GET/POST | /api/events | Eventos |

## Notas importantes

- Cambia `JWT_SECRET` en `backend/.env` antes de producción
- En `mobile/src/services/api.js` pon la IP real de tu ordenador
- El móvil y el PC deben estar en la misma red WiFi
- Límite de archivos: 50 MB (fotos y videos)

---
Prototipo funcional listo para ampliar y desplegar.
