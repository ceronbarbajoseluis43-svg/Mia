import { useState, useEffect } from 'react'
import axios from 'axios'

const API = axios.create({
  baseURL: '/api'
})

// Interceptor para añadir token
API.interceptors.request.use((config) => {
  const token = localStorage.getItem('token')
  if (token) {
    config.headers.Authorization = `Bearer ${token}`
  }
  return config
})

function App() {
  const [user, setUser] = useState(null)
  const [view, setView] = useState('login') // login | register | feed | profile | search
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState('')
  const [success, setSuccess] = useState('')

  // Formularios
  const [loginForm, setLoginForm] = useState({ email: '', password: '' })
  const [registerForm, setRegisterForm] = useState({
    email: '',
    password: '',
    displayName: '',
    birthDate: '',
    gender: '',
    relationshipStatus: 'single',
    city: '',
    country: ''
  })
  const [posts, setPosts] = useState([])
  const [newPost, setNewPost] = useState('')
  const [searchQuery, setSearchQuery] = useState('')
  const [searchResults, setSearchResults] = useState([])

  useEffect(() => {
    const token = localStorage.getItem('token')
    if (token) {
      loadMe()
    }
  }, [])

  const loadMe = async () => {
    try {
      const { data } = await API.get('/users/me')
      setUser(data.user)
      setView('feed')
      loadFeed()
    } catch (err) {
      localStorage.removeItem('token')
      setUser(null)
    }
  }

  const loadFeed = async () => {
    try {
      const { data } = await API.get('/posts/feed')
      setPosts(data.posts || [])
    } catch (err) {
      console.error(err)
    }
  }

  const handleLogin = async (e) => {
    e.preventDefault()
    setLoading(true)
    setError('')
    try {
      const { data } = await API.post('/auth/login', loginForm)
      localStorage.setItem('token', data.token)
      setUser(data.user)
      setView('feed')
      loadFeed()
      setSuccess('¡Bienvenido/a!')
    } catch (err) {
      setError(err.response?.data?.error || 'Error al iniciar sesión')
    } finally {
      setLoading(false)
    }
  }

  const handleRegister = async (e) => {
    e.preventDefault()
    setLoading(true)
    setError('')
    try {
      const { data } = await API.post('/auth/register', registerForm)
      localStorage.setItem('token', data.token)
      setUser(data.user)
      setView('feed')
      setSuccess('¡Registro exitoso! Bienvenido/a a la comunidad.')
    } catch (err) {
      setError(err.response?.data?.error || 'Error en el registro')
    } finally {
      setLoading(false)
    }
  }

  const handleCreatePost = async (e) => {
    e.preventDefault()
    if (!newPost.trim()) return
    try {
      await API.post('/posts', { content: newPost, visibility: 'friends' })
      setNewPost('')
      loadFeed()
      setSuccess('Publicación creada')
    } catch (err) {
      setError(err.response?.data?.error || 'Error al publicar')
    }
  }

  const handleSearch = async (e) => {
    e.preventDefault()
    try {
      const { data } = await API.get(`/users/search?q=${encodeURIComponent(searchQuery)}`)
      setSearchResults(data.users || [])
    } catch (err) {
      setError('Error en la búsqueda')
    }
  }

  const logout = () => {
    localStorage.removeItem('token')
    setUser(null)
    setView('login')
    setPosts([])
  }

  // ========== VISTAS ==========

  if (!user) {
    return (
      <div className="container">
        <div style={{ textAlign: 'center', marginBottom: 32 }}>
          <h1 style={{ fontSize: 28, marginBottom: 8 }}>🔥 SwingerConnect</h1>
          <p style={{ color: '#a0a0b0', fontSize: 14 }}>Solo para mayores de 18 años</p>
        </div>

        <div className="nav">
          <button className={view === 'login' ? 'active' : ''} onClick={() => { setView('login'); setError('') }}>
            Iniciar sesión
          </button>
          <button className={view === 'register' ? 'active' : ''} onClick={() => { setView('register'); setError('') }}>
            Registrarse
          </button>
        </div>

        {error && <div className="error" style={{ marginBottom: 16 }}>{error}</div>}
        {success && <div className="success" style={{ marginBottom: 16 }}>{success}</div>}

        {view === 'login' && (
          <div className="card">
            <form onSubmit={handleLogin}>
              <div className="form-group">
                <label>Email</label>
                <input
                  type="email"
                  value={loginForm.email}
                  onChange={(e) => setLoginForm({ ...loginForm, email: e.target.value })}
                  required
                />
              </div>
              <div className="form-group">
                <label>Contraseña</label>
                <input
                  type="password"
                  value={loginForm.password}
                  onChange={(e) => setLoginForm({ ...loginForm, password: e.target.value })}
                  required
                />
              </div>
              <button type="submit" className="primary" style={{ width: '100%' }} disabled={loading}>
                {loading ? 'Entrando...' : 'Entrar'}
              </button>
            </form>
          </div>
        )}

        {view === 'register' && (
          <div className="card">
            <form onSubmit={handleRegister}>
              <div className="form-group">
                <label>Nombre visible *</label>
                <input
                  value={registerForm.displayName}
                  onChange={(e) => setRegisterForm({ ...registerForm, displayName: e.target.value })}
                  required
                  placeholder="Ej: Alex & Sam"
                />
              </div>
              <div className="form-group">
                <label>Email *</label>
                <input
                  type="email"
                  value={registerForm.email}
                  onChange={(e) => setRegisterForm({ ...registerForm, email: e.target.value })}
                  required
                />
              </div>
              <div className="form-group">
                <label>Contraseña * (mín. 8 caracteres)</label>
                <input
                  type="password"
                  value={registerForm.password}
                  onChange={(e) => setRegisterForm({ ...registerForm, password: e.target.value })}
                  required
                  minLength={8}
                />
              </div>
              <div className="form-group">
                <label>Fecha de nacimiento * (debes ser mayor de 18)</label>
                <input
                  type="date"
                  value={registerForm.birthDate}
                  onChange={(e) => setRegisterForm({ ...registerForm, birthDate: e.target.value })}
                  required
                />
              </div>
              <div className="form-group">
                <label>Estado de relación</label>
                <select
                  value={registerForm.relationshipStatus}
                  onChange={(e) => setRegisterForm({ ...registerForm, relationshipStatus: e.target.value })}
                >
                  <option value="single">Soltero/a</option>
                  <option value="couple">Pareja</option>
                  <option value="married">Casados</option>
                  <option value="open">Relación abierta</option>
                  <option value="other">Otro</option>
                </select>
              </div>
              <div className="form-group">
                <label>Ciudad</label>
                <input
                  value={registerForm.city}
                  onChange={(e) => setRegisterForm({ ...registerForm, city: e.target.value })}
                  placeholder="Madrid"
                />
              </div>
              <div className="form-group">
                <label>País</label>
                <input
                  value={registerForm.country}
                  onChange={(e) => setRegisterForm({ ...registerForm, country: e.target.value })}
                  placeholder="España"
                />
              </div>
              <button type="submit" className="primary" style={{ width: '100%' }} disabled={loading}>
                {loading ? 'Registrando...' : 'Crear cuenta (18+)'}
              </button>
            </form>
          </div>
        )}
      </div>
    )
  }

  // Usuario logueado
  return (
    <div className="container">
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 24 }}>
        <div>
          <h2 style={{ fontSize: 20 }}>🔥 SwingerConnect</h2>
          <p style={{ fontSize: 13, color: '#a0a0b0' }}>Hola, {user.displayName}</p>
        </div>
        <button className="secondary" onClick={logout}>Salir</button>
      </div>

      <div className="nav">
        <button className={view === 'feed' ? 'active' : ''} onClick={() => { setView('feed'); loadFeed() }}>
          Feed
        </button>
        <button className={view === 'search' ? 'active' : ''} onClick={() => setView('search')}>
          Buscar
        </button>
        <button className={view === 'profile' ? 'active' : ''} onClick={() => setView('profile')}>
          Perfil
        </button>
      </div>

      {error && <div className="error" style={{ marginBottom: 12 }}>{error}</div>}
      {success && <div className="success" style={{ marginBottom: 12 }}>{success}</div>}

      {view === 'feed' && (
        <>
          <div className="card">
            <form onSubmit={handleCreatePost}>
              <textarea
                rows={3}
                placeholder="¿Qué estás pensando? Comparte con la comunidad..."
                value={newPost}
                onChange={(e) => setNewPost(e.target.value)}
                style={{ marginBottom: 12 }}
              />
              <button type="submit" className="primary">Publicar</button>
            </form>
          </div>

          {posts.length === 0 && (
            <p style={{ textAlign: 'center', color: '#a0a0b0', marginTop: 32 }}>
              Aún no hay publicaciones. ¡Sé el primero!
            </p>
          )}

          {posts.map((post) => (
            <div key={post.id} className="card">
              <div style={{ display: 'flex', alignItems: 'center', gap: 10, marginBottom: 10 }}>
                <div style={{
                  width: 40, height: 40, borderRadius: '50%',
                  background: '#ff6b9d', display: 'flex',
                  alignItems: 'center', justifyContent: 'center',
                  fontWeight: 'bold'
                }}>
                  {post.author?.displayName?.[0] || '?'}
                </div>
                <div>
                  <strong>{post.author?.displayName}</strong>
                  {post.author?.isVerified && <span style={{ marginLeft: 6, color: '#51cf66' }}>✓</span>}
                  <div style={{ fontSize: 12, color: '#a0a0b0' }}>
                    {new Date(post.createdAt).toLocaleString('es')}
                  </div>
                </div>
              </div>
              <p style={{ whiteSpace: 'pre-wrap', lineHeight: 1.5 }}>{post.content}</p>
            </div>
          ))}
        </>
      )}

      {view === 'search' && (
        <div className="card">
          <form onSubmit={handleSearch}>
            <div className="form-group">
              <label>Buscar personas</label>
              <input
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                placeholder="Nombre, ciudad..."
              />
            </div>
            <button type="submit" className="primary">Buscar</button>
          </form>

          <div style={{ marginTop: 20 }}>
            {searchResults.map((u) => (
              <div key={u.id} style={{
                padding: '12px 0',
                borderBottom: '1px solid #2a2a35',
                display: 'flex',
                justifyContent: 'space-between',
                alignItems: 'center'
              }}>
                <div>
                  <strong>{u.displayName}</strong>
                  {u.isVerified && <span style={{ marginLeft: 6, color: '#51cf66' }}>✓</span>}
                  <div style={{ fontSize: 13, color: '#a0a0b0' }}>
                    {u.relationshipStatus} {u.city && `· ${u.city}`}
                  </div>
                  {u.lookingFor && (
                    <div style={{ fontSize: 12, color: '#ff6b9d', marginTop: 4 }}>
                      Busca: {u.lookingFor}
                    </div>
                  )}
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {view === 'profile' && (
        <div className="card">
          <h3 style={{ marginBottom: 16 }}>Mi perfil</h3>
          <p><strong>Nombre:</strong> {user.displayName}</p>
          <p><strong>Email:</strong> {user.email}</p>
          {user.city && <p><strong>Ciudad:</strong> {user.city}</p>}
          <p style={{ marginTop: 16, fontSize: 13, color: '#a0a0b0' }}>
            Puedes ampliar la edición de perfil (bio, preferencias, lookingFor, etc.) usando el endpoint PUT /api/users/me
          </p>
        </div>
      )}
    </div>
  )
}

export default App
