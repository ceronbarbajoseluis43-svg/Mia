/**
 * Utilidades de verificación de edad (18+)
 */

function calculateAge(birthDate) {
  const today = new Date();
  const birth = new Date(birthDate);
  let age = today.getFullYear() - birth.getFullYear();
  const monthDiff = today.getMonth() - birth.getMonth();
  
  if (monthDiff < 0 || (monthDiff === 0 && today.getDate() < birth.getDate())) {
    age--;
  }
  return age;
}

function isAdult(birthDate) {
  return calculateAge(birthDate) >= 18;
}

module.exports = { calculateAge, isAdult };
