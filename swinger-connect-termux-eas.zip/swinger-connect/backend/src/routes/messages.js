const express = require('express');
const { body, validationResult } = require('express-validator');
const { PrismaClient } = require('@prisma/client');
const { authMiddleware } = require('../middleware/auth');

const router = express.Router();
const prisma = new PrismaClient();

router.use(authMiddleware);

// Enviar mensaje (texto + foto/video opcional)
router.post(
  '/',
  [
    body('receiverId').isUUID(),
    body('content').optional().trim().isLength({ max: 2000 }),
    body('mediaUrl').optional().isString(),
    body('mediaType').optional().isIn(['image', 'video'])
  ],
  async (req, res) => {
    try {
      const errors = validationResult(req);
      if (!errors.isEmpty()) {
        return res.status(400).json({ errors: errors.array() });
      }

      const { receiverId, content = '', mediaUrl, mediaType } = req.body;

      if (receiverId === req.user.id) {
        return res.status(400).json({ error: 'No puedes enviarte mensajes a ti mismo' });
      }

      if (!content && !mediaUrl) {
        return res.status(400).json({ error: 'El mensaje no puede estar vacío' });
      }

      // Solo a amigos aceptados
      const friendship = await prisma.friendship.findFirst({
        where: {
          status: 'accepted',
          OR: [
            { senderId: req.user.id, receiverId },
            { senderId: receiverId, receiverId: req.user.id }
          ]
        }
      });

      if (!friendship) {
        return res.status(403).json({
          error: 'Solo puedes enviar mensajes a personas con conexión aceptada'
        });
      }

      const message = await prisma.message.create({
        data: {
          senderId: req.user.id,
          receiverId,
          content: content || '',
          mediaUrl: mediaUrl || null,
          mediaType: mediaType || null
        },
        include: {
          sender: { select: { id: true, displayName: true, avatarUrl: true } }
        }
      });

      res.status(201).json({ message: 'Mensaje enviado', data: message });
    } catch (error) {
      console.error(error);
      res.status(500).json({ error: 'Error al enviar mensaje' });
    }
  }
);

// Conversación con un usuario
router.get('/with/:userId', async (req, res) => {
  try {
    const otherId = req.params.userId;

    const messages = await prisma.message.findMany({
      where: {
        OR: [
          { senderId: req.user.id, receiverId: otherId },
          { senderId: otherId, receiverId: req.user.id }
        ]
      },
      orderBy: { createdAt: 'asc' },
      include: {
        sender: { select: { id: true, displayName: true, avatarUrl: true } }
      },
      take: 150
    });

    // Marcar como leídos
    await prisma.message.updateMany({
      where: {
        senderId: otherId,
        receiverId: req.user.id,
        isRead: false
      },
      data: { isRead: true }
    });

    res.json({ messages });
  } catch (error) {
    res.status(500).json({ error: 'Error al cargar conversación' });
  }
});

// Lista de conversaciones
router.get('/', async (req, res) => {
  try {
    const messages = await prisma.message.findMany({
      where: {
        OR: [
          { senderId: req.user.id },
          { receiverId: req.user.id }
        ]
      },
      orderBy: { createdAt: 'desc' },
      take: 200,
      include: {
        sender: { select: { id: true, displayName: true, avatarUrl: true } },
        receiver: { select: { id: true, displayName: true, avatarUrl: true } }
      }
    });

    const conversationsMap = new Map();

    for (const msg of messages) {
      const otherUser = msg.senderId === req.user.id ? msg.receiver : msg.sender;
      if (!conversationsMap.has(otherUser.id)) {
        conversationsMap.set(otherUser.id, {
          otherUser,
          lastMessage: msg,
          unreadCount: 0
        });
      }
      if (msg.receiverId === req.user.id && !msg.isRead) {
        conversationsMap.get(otherUser.id).unreadCount++;
      }
    }

    const conversations = Array.from(conversationsMap.values());
    res.json({ conversations });
  } catch (error) {
    console.error(error);
    res.status(500).json({ error: 'Error al listar conversaciones' });
  }
});

module.exports = router;
