const express = require('express');
const { PrismaClient } = require('@prisma/client');
const { authMiddleware } = require('../middleware/auth');

const router = express.Router();
const prisma = new PrismaClient();

router.use(authMiddleware);

// Enviar solicitud de conexión
router.post('/request/:userId', async (req, res) => {
  try {
    const receiverId = req.params.userId;

    if (receiverId === req.user.id) {
      return res.status(400).json({ error: 'No puedes enviarte solicitud a ti mismo' });
    }

    // Verificar que el usuario existe
    const receiver = await prisma.user.findUnique({ where: { id: receiverId } });
    if (!receiver || !receiver.isActive) {
      return res.status(404).json({ error: 'Usuario no encontrado' });
    }

    // Verificar si ya existe alguna relación
    const existing = await prisma.friendship.findFirst({
      where: {
        OR: [
          { senderId: req.user.id, receiverId },
          { senderId: receiverId, receiverId: req.user.id }
        ]
      }
    });

    if (existing) {
      return res.status(409).json({
        error: 'Ya existe una solicitud o conexión con este usuario',
        status: existing.status
      });
    }

    const friendship = await prisma.friendship.create({
      data: {
        senderId: req.user.id,
        receiverId,
        status: 'pending'
      },
      include: {
        receiver: {
          select: { id: true, displayName: true, avatarUrl: true }
        }
      }
    });

    res.status(201).json({ message: 'Solicitud enviada', friendship });
  } catch (error) {
    console.error(error);
    res.status(500).json({ error: 'Error al enviar solicitud' });
  }
});

// Aceptar solicitud
router.post('/accept/:friendshipId', async (req, res) => {
  try {
    const friendship = await prisma.friendship.findUnique({
      where: { id: req.params.friendshipId }
    });

    if (!friendship) {
      return res.status(404).json({ error: 'Solicitud no encontrada' });
    }
    if (friendship.receiverId !== req.user.id) {
      return res.status(403).json({ error: 'No puedes aceptar esta solicitud' });
    }
    if (friendship.status !== 'pending') {
      return res.status(400).json({ error: 'Esta solicitud ya no está pendiente' });
    }

    const updated = await prisma.friendship.update({
      where: { id: friendship.id },
      data: { status: 'accepted' },
      include: {
        sender: { select: { id: true, displayName: true, avatarUrl: true } }
      }
    });

    res.json({ message: 'Conexión aceptada', friendship: updated });
  } catch (error) {
    res.status(500).json({ error: 'Error al aceptar solicitud' });
  }
});

// Rechazar / cancelar
router.post('/reject/:friendshipId', async (req, res) => {
  try {
    const friendship = await prisma.friendship.findUnique({
      where: { id: req.params.friendshipId }
    });

    if (!friendship) {
      return res.status(404).json({ error: 'Solicitud no encontrada' });
    }

    const isParticipant =
      friendship.senderId === req.user.id || friendship.receiverId === req.user.id;

    if (!isParticipant) {
      return res.status(403).json({ error: 'No autorizado' });
    }

    await prisma.friendship.update({
      where: { id: friendship.id },
      data: { status: 'rejected' }
    });

    res.json({ message: 'Solicitud rechazada' });
  } catch (error) {
    res.status(500).json({ error: 'Error al rechazar' });
  }
});

// Listar mis conexiones y solicitudes
router.get('/', async (req, res) => {
  try {
    const friendships = await prisma.friendship.findMany({
      where: {
        OR: [
          { senderId: req.user.id },
          { receiverId: req.user.id }
        ]
      },
      include: {
        sender: {
          select: { id: true, displayName: true, avatarUrl: true, relationshipStatus: true, city: true }
        },
        receiver: {
          select: { id: true, displayName: true, avatarUrl: true, relationshipStatus: true, city: true }
        }
      },
      orderBy: { updatedAt: 'desc' }
    });

    const connections = friendships.map(f => {
      const isSender = f.senderId === req.user.id;
      return {
        id: f.id,
        status: f.status,
        isIncoming: !isSender && f.status === 'pending',
        isOutgoing: isSender && f.status === 'pending',
        otherUser: isSender ? f.receiver : f.sender,
        createdAt: f.createdAt
      };
    });

    res.json({ connections });
  } catch (error) {
    console.error(error);
    res.status(500).json({ error: 'Error al listar conexiones' });
  }
});

module.exports = router;
