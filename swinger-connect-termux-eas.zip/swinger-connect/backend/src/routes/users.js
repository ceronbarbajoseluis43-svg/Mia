const express = require('express');
const { body, validationResult } = require('express-validator');
const { PrismaClient } = require('@prisma/client');
const { authMiddleware } = require('../middleware/auth');

const router = express.Router();
const prisma = new PrismaClient();

router.use(authMiddleware);

// Perfil propio completo
router.get('/me', async (req, res) => {
  try {
    const user = await prisma.user.findUnique({
      where: { id: req.user.id },
      select: {
        id: true,
        email: true,
        displayName: true,
        birthDate: true,
        gender: true,
        orientation: true,
        relationshipStatus: true,
        bio: true,
        city: true,
        country: true,
        lookingFor: true,
        preferences: true,
        avatarUrl: true,
        isVerified: true,
        createdAt: true
      }
    });
    res.json({ user });
  } catch (error) {
    res.status(500).json({ error: 'Error al obtener perfil' });
  }
});

// Actualizar perfil (completo)
router.put(
  '/me',
  [
    body('displayName').optional().trim().isLength({ min: 2, max: 50 }),
    body('bio').optional().isLength({ max: 1000 }),
    body('gender').optional().isString(),
    body('orientation').optional().isString(),
    body('relationshipStatus').optional().isString(),
    body('lookingFor').optional().isString(),
    body('preferences').optional().isString(),
    body('city').optional().isString(),
    body('country').optional().isString(),
    body('avatarUrl').optional().isString()
  ],
  async (req, res) => {
    try {
      const errors = validationResult(req);
      if (!errors.isEmpty()) {
        return res.status(400).json({ errors: errors.array() });
      }

      const allowed = [
        'displayName', 'bio', 'gender', 'orientation',
        'relationshipStatus', 'lookingFor', 'preferences',
        'city', 'country', 'avatarUrl'
      ];

      const data = {};
      allowed.forEach(f => {
        if (req.body[f] !== undefined) data[f] = req.body[f];
      });

      const updated = await prisma.user.update({
        where: { id: req.user.id },
        data,
        select: {
          id: true,
          displayName: true,
          bio: true,
          gender: true,
          orientation: true,
          relationshipStatus: true,
          lookingFor: true,
          preferences: true,
          city: true,
          country: true,
          avatarUrl: true,
          isVerified: true
        }
      });

      res.json({ message: 'Perfil actualizado', user: updated });
    } catch (error) {
      console.error(error);
      res.status(500).json({ error: 'Error al actualizar perfil' });
    }
  }
);

// Buscar usuarios
router.get('/search', async (req, res) => {
  try {
    const { q, city, relationshipStatus, limit = 20 } = req.query;

    const where = {
      isActive: true,
      isVerifiedAge: true,
      id: { not: req.user.id }
    };

    if (q) {
      where.OR = [
        { displayName: { contains: q } },
        { bio: { contains: q } },
        { city: { contains: q } }
      ];
    }
    if (city) where.city = { contains: city };
    if (relationshipStatus) where.relationshipStatus = relationshipStatus;

    const users = await prisma.user.findMany({
      where,
      take: Math.min(parseInt(limit) || 20, 50),
      select: {
        id: true,
        displayName: true,
        gender: true,
        relationshipStatus: true,
        city: true,
        country: true,
        lookingFor: true,
        avatarUrl: true,
        isVerified: true,
        bio: true
      },
      orderBy: { createdAt: 'desc' }
    });

    res.json({ users });
  } catch (error) {
    console.error(error);
    res.status(500).json({ error: 'Error en la búsqueda' });
  }
});

// Ver perfil de otro
router.get('/:id', async (req, res) => {
  try {
    if (req.params.id === 'me' || req.params.id === 'search') {
      return res.status(400).json({ error: 'ID inválido' });
    }

    const user = await prisma.user.findUnique({
      where: { id: req.params.id },
      select: {
        id: true,
        displayName: true,
        gender: true,
        orientation: true,
        relationshipStatus: true,
        bio: true,
        city: true,
        country: true,
        lookingFor: true,
        preferences: true,
        avatarUrl: true,
        isVerified: true,
        createdAt: true
      }
    });

    if (!user) {
      return res.status(404).json({ error: 'Usuario no encontrado' });
    }

    res.json({ user });
  } catch (error) {
    res.status(500).json({ error: 'Error al obtener usuario' });
  }
});

module.exports = router;
