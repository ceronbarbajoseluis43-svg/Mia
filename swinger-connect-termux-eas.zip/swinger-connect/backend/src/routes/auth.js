const express = require('express');
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const { body, validationResult } = require('express-validator');
const { PrismaClient } = require('@prisma/client');
const { isAdult } = require('../utils/age');

const router = express.Router();
const prisma = new PrismaClient();

// Registro
router.post(
  '/register',
  [
    body('email').isEmail().normalizeEmail(),
    body('password').isLength({ min: 8 }).withMessage('La contraseña debe tener al menos 8 caracteres'),
    body('displayName').trim().isLength({ min: 2, max: 50 }),
    body('birthDate').isISO8601().toDate(),
    body('gender').optional().isString(),
    body('relationshipStatus').optional().isString()
  ],
  async (req, res) => {
    try {
      const errors = validationResult(req);
      if (!errors.isEmpty()) {
        return res.status(400).json({ errors: errors.array() });
      }

      const { email, password, displayName, birthDate, gender, relationshipStatus, city, country } = req.body;

      // Verificación estricta de edad 18+
      if (!isAdult(birthDate)) {
        return res.status(403).json({
          error: 'Debes ser mayor de 18 años para registrarte en esta plataforma'
        });
      }

      // Verificar si el email ya existe
      const existingUser = await prisma.user.findUnique({ where: { email } });
      if (existingUser) {
        return res.status(409).json({ error: 'Este email ya está registrado' });
      }

      const passwordHash = await bcrypt.hash(password, 12);

      const user = await prisma.user.create({
        data: {
          email,
          passwordHash,
          displayName,
          birthDate: new Date(birthDate),
          isVerifiedAge: true, // Ya validamos en servidor
          gender: gender || null,
          relationshipStatus: relationshipStatus || null,
          city: city || null,
          country: country || null
        },
        select: {
          id: true,
          email: true,
          displayName: true,
          birthDate: true,
          isVerifiedAge: true,
          createdAt: true
        }
      });

      const token = jwt.sign(
        { userId: user.id },
        process.env.JWT_SECRET,
        { expiresIn: '7d' }
      );

      res.status(201).json({
        message: 'Usuario registrado correctamente. Bienvenido/a a la comunidad.',
        user,
        token
      });
    } catch (error) {
      console.error('Error en registro:', error);
      res.status(500).json({ error: 'Error interno del servidor' });
    }
  }
);

// Login
router.post(
  '/login',
  [
    body('email').isEmail().normalizeEmail(),
    body('password').notEmpty()
  ],
  async (req, res) => {
    try {
      const errors = validationResult(req);
      if (!errors.isEmpty()) {
        return res.status(400).json({ errors: errors.array() });
      }

      const { email, password } = req.body;

      const user = await prisma.user.findUnique({ where: { email } });
      if (!user) {
        return res.status(401).json({ error: 'Credenciales incorrectas' });
      }

      const validPassword = await bcrypt.compare(password, user.passwordHash);
      if (!validPassword) {
        return res.status(401).json({ error: 'Credenciales incorrectas' });
      }

      if (!user.isActive) {
        return res.status(403).json({ error: 'Cuenta desactivada' });
      }

      // Doble check de edad
      if (!isAdult(user.birthDate)) {
        return res.status(403).json({ error: 'Debes ser mayor de 18 años' });
      }

      const token = jwt.sign(
        { userId: user.id },
        process.env.JWT_SECRET,
        { expiresIn: '7d' }
      );

      res.json({
        message: 'Login exitoso',
        user: {
          id: user.id,
          email: user.email,
          displayName: user.displayName,
          isVerified: user.isVerified,
          avatarUrl: user.avatarUrl
        },
        token
      });
    } catch (error) {
      console.error('Error en login:', error);
      res.status(500).json({ error: 'Error interno del servidor' });
    }
  }
);

// Perfil del usuario autenticado
router.get('/me', async (req, res) => {
  // Este endpoint requiere authMiddleware (se montará en el router principal)
  res.json({ user: req.user });
});

module.exports = router;
