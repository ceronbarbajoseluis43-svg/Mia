const express = require('express');
const { body, validationResult } = require('express-validator');
const { PrismaClient } = require('@prisma/client');
const { authMiddleware } = require('../middleware/auth');

const router = express.Router();
const prisma = new PrismaClient();

router.use(authMiddleware);

// Crear publicación (texto + foto/video opcional)
router.post(
  '/',
  [
    body('content').optional().trim().isLength({ max: 2000 }),
    body('visibility').optional().isIn(['public', 'friends', 'private']),
    body('mediaUrl').optional().isString(),
    body('mediaType').optional().isIn(['image', 'video'])
  ],
  async (req, res) => {
    try {
      const errors = validationResult(req);
      if (!errors.isEmpty()) {
        return res.status(400).json({ errors: errors.array() });
      }

      const { content = '', visibility = 'friends', mediaUrl, mediaType } = req.body;

      if (!content && !mediaUrl) {
        return res.status(400).json({ error: 'Debes escribir algo o adjuntar una foto/video' });
      }

      const post = await prisma.post.create({
        data: {
          authorId: req.user.id,
          content: content || '',
          visibility,
          mediaUrl: mediaUrl || null,
          mediaType: mediaType || null
        },
        include: {
          author: {
            select: {
              id: true,
              displayName: true,
              avatarUrl: true,
              isVerified: true,
              relationshipStatus: true
            }
          }
        }
      });

      res.status(201).json({ message: 'Publicación creada', post });
    } catch (error) {
      console.error(error);
      res.status(500).json({ error: 'Error al crear publicación' });
    }
  }
);

// Feed
router.get('/feed', async (req, res) => {
  try {
    const friendships = await prisma.friendship.findMany({
      where: {
        status: 'accepted',
        OR: [
          { senderId: req.user.id },
          { receiverId: req.user.id }
        ]
      }
    });

    const friendIds = friendships.map(f =>
      f.senderId === req.user.id ? f.receiverId : f.senderId
    );

    const posts = await prisma.post.findMany({
      where: {
        OR: [
          { authorId: req.user.id },
          { visibility: 'public' },
          {
            AND: [
              { authorId: { in: friendIds } },
              { visibility: { in: ['public', 'friends'] } }
            ]
          }
        ]
      },
      include: {
        author: {
          select: {
            id: true,
            displayName: true,
            avatarUrl: true,
            isVerified: true,
            relationshipStatus: true
          }
        }
      },
      orderBy: { createdAt: 'desc' },
      take: 50
    });

    res.json({ posts });
  } catch (error) {
    console.error(error);
    res.status(500).json({ error: 'Error al cargar el feed' });
  }
});

// Mis publicaciones
router.get('/me', async (req, res) => {
  try {
    const posts = await prisma.post.findMany({
      where: { authorId: req.user.id },
      orderBy: { createdAt: 'desc' },
      include: {
        author: {
          select: { id: true, displayName: true, avatarUrl: true }
        }
      }
    });
    res.json({ posts });
  } catch (error) {
    res.status(500).json({ error: 'Error al obtener publicaciones' });
  }
});

// Eliminar
router.delete('/:id', async (req, res) => {
  try {
    const post = await prisma.post.findUnique({ where: { id: req.params.id } });
    if (!post) return res.status(404).json({ error: 'Publicación no encontrada' });
    if (post.authorId !== req.user.id) {
      return res.status(403).json({ error: 'No puedes eliminar esta publicación' });
    }
    await prisma.post.delete({ where: { id: req.params.id } });
    res.json({ message: 'Publicación eliminada' });
  } catch (error) {
    res.status(500).json({ error: 'Error al eliminar' });
  }
});

module.exports = router;
