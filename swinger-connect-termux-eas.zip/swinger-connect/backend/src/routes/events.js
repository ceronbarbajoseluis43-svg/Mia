const express = require('express');
const { body, validationResult } = require('express-validator');
const { PrismaClient } = require('@prisma/client');
const { authMiddleware } = require('../middleware/auth');

const router = express.Router();
const prisma = new PrismaClient();

router.use(authMiddleware);

// Crear evento
router.post(
  '/',
  [
    body('title').trim().isLength({ min: 3, max: 120 }),
    body('description').optional().isLength({ max: 2000 }),
    body('location').optional().isString(),
    body('city').optional().isString(),
    body('startDate').isISO8601(),
    body('endDate').optional().isISO8601(),
    body('isPrivate').optional().isBoolean(),
    body('maxAttendees').optional().isInt({ min: 1 }),
    body('coverUrl').optional().isString()
  ],
  async (req, res) => {
    try {
      const errors = validationResult(req);
      if (!errors.isEmpty()) {
        return res.status(400).json({ errors: errors.array() });
      }

      const {
        title, description, location, city,
        startDate, endDate, isPrivate, maxAttendees, coverUrl
      } = req.body;

      const event = await prisma.event.create({
        data: {
          creatorId: req.user.id,
          title,
          description: description || null,
          location: location || null,
          city: city || null,
          startDate: new Date(startDate),
          endDate: endDate ? new Date(endDate) : null,
          isPrivate: isPrivate || false,
          maxAttendees: maxAttendees || null,
          coverUrl: coverUrl || null
        },
        include: {
          creator: {
            select: { id: true, displayName: true, avatarUrl: true }
          },
          _count: { select: { attendees: true } }
        }
      });

      // El creador se apunta automáticamente como "going"
      await prisma.eventAttendee.create({
        data: {
          eventId: event.id,
          userId: req.user.id,
          status: 'going'
        }
      });

      res.status(201).json({ message: 'Evento creado', event });
    } catch (error) {
      console.error(error);
      res.status(500).json({ error: 'Error al crear el evento' });
    }
  }
);

// Listar eventos (próximos + públicos o de amigos)
router.get('/', async (req, res) => {
  try {
    const { city, upcoming = 'true' } = req.query;

    const where = {
      OR: [
        { isPrivate: false },
        { creatorId: req.user.id }
      ]
    };

    if (city) where.city = { contains: city };
    if (upcoming === 'true') {
      where.startDate = { gte: new Date() };
    }

    const events = await prisma.event.findMany({
      where,
      orderBy: { startDate: 'asc' },
      take: 50,
      include: {
        creator: {
          select: { id: true, displayName: true, avatarUrl: true, isVerified: true }
        },
        attendees: {
          where: { userId: req.user.id },
          select: { status: true }
        },
        _count: { select: { attendees: true } }
      }
    });

    const formatted = events.map(e => ({
      ...e,
      myStatus: e.attendees[0]?.status || null,
      attendeesCount: e._count.attendees,
      attendees: undefined,
      _count: undefined
    }));

    res.json({ events: formatted });
  } catch (error) {
    console.error(error);
    res.status(500).json({ error: 'Error al listar eventos' });
  }
});

// Detalle de un evento
router.get('/:id', async (req, res) => {
  try {
    const event = await prisma.event.findUnique({
      where: { id: req.params.id },
      include: {
        creator: {
          select: { id: true, displayName: true, avatarUrl: true, isVerified: true }
        },
        attendees: {
          include: {
            user: {
              select: { id: true, displayName: true, avatarUrl: true, relationshipStatus: true }
            }
          }
        }
      }
    });

    if (!event) {
      return res.status(404).json({ error: 'Evento no encontrado' });
    }

    res.json({ event });
  } catch (error) {
    res.status(500).json({ error: 'Error al obtener evento' });
  }
});

// Apuntarse / cambiar estado
router.post('/:id/attend', async (req, res) => {
  try {
    const { status = 'going' } = req.body; // interested | going | not_going
    if (!['interested', 'going', 'not_going'].includes(status)) {
      return res.status(400).json({ error: 'Estado inválido' });
    }

    const event = await prisma.event.findUnique({ where: { id: req.params.id } });
    if (!event) {
      return res.status(404).json({ error: 'Evento no encontrado' });
    }

    const attendee = await prisma.eventAttendee.upsert({
      where: {
        eventId_userId: {
          eventId: req.params.id,
          userId: req.user.id
        }
      },
      update: { status },
      create: {
        eventId: req.params.id,
        userId: req.user.id,
        status
      }
    });

    res.json({ message: 'Estado actualizado', attendee });
  } catch (error) {
    console.error(error);
    res.status(500).json({ error: 'Error al actualizar asistencia' });
  }
});

// Eliminar evento (solo creador)
router.delete('/:id', async (req, res) => {
  try {
    const event = await prisma.event.findUnique({ where: { id: req.params.id } });
    if (!event) return res.status(404).json({ error: 'Evento no encontrado' });
    if (event.creatorId !== req.user.id) {
      return res.status(403).json({ error: 'Solo el creador puede eliminar el evento' });
    }

    await prisma.event.delete({ where: { id: req.params.id } });
    res.json({ message: 'Evento eliminado' });
  } catch (error) {
    res.status(500).json({ error: 'Error al eliminar' });
  }
});

module.exports = router;
