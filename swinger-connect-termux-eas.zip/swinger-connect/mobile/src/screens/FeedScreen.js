import React, { useState, useEffect, useCallback } from 'react';
import {
  View, Text, TextInput, TouchableOpacity, StyleSheet, FlatList,
  ActivityIndicator, RefreshControl, Alert, Image
} from 'react-native';
import * as ImagePicker from 'expo-image-picker';
import { postsAPI, uploadAPI, getMediaUrl } from '../services/api';

export default function FeedScreen() {
  const [posts, setPosts] = useState([]);
  const [newPost, setNewPost] = useState('');
  const [media, setMedia] = useState(null); // { uri, mediaUrl, mediaType }
  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);
  const [posting, setPosting] = useState(false);

  const loadFeed = useCallback(async () => {
    try {
      const { data } = await postsAPI.feed();
      setPosts(data.posts || []);
    } catch (err) {
      console.log(err);
    } finally {
      setLoading(false);
      setRefreshing(false);
    }
  }, []);

  useEffect(() => { loadFeed(); }, [loadFeed]);

  const pickMedia = async () => {
    const { status } = await ImagePicker.requestMediaLibraryPermissionsAsync();
    if (status !== 'granted') {
      Alert.alert('Permiso necesario', 'Necesitamos acceso a la galería');
      return;
    }
    const result = await ImagePicker.launchImageLibraryAsync({
      mediaTypes: ImagePicker.MediaTypeOptions.All,
      quality: 0.8,
    });
    if (!result.canceled && result.assets[0]) {
      const asset = result.assets[0];
      setMedia({
        uri: asset.uri,
        type: asset.type === 'video' ? 'video' : 'image',
      });
    }
  };

  const handleCreatePost = async () => {
    if (!newPost.trim() && !media) return;
    setPosting(true);
    try {
      let mediaUrl = null;
      let mediaType = null;

      if (media) {
        const data = await uploadAPI.upload(
          media.uri,
          media.type === 'video' ? 'video/mp4' : 'image/jpeg'
        );
        mediaUrl = data.mediaUrl;
        mediaType = data.mediaType;
      }

      await postsAPI.create({
        content: newPost.trim(),
        visibility: 'friends',
        mediaUrl,
        mediaType,
      });
      setNewPost('');
      setMedia(null);
      loadFeed();
    } catch (err) {
      Alert.alert('Error', err.response?.data?.error || err.message || 'No se pudo publicar');
    } finally {
      setPosting(false);
    }
  };

  const renderPost = ({ item }) => (
    <View style={styles.postCard}>
      <View style={styles.postHeader}>
        <View style={styles.avatar}>
          {item.author?.avatarUrl ? (
            <Image source={{ uri: getMediaUrl(item.author.avatarUrl) }} style={styles.avatarImg} />
          ) : (
            <Text style={styles.avatarText}>{item.author?.displayName?.[0]?.toUpperCase() || '?'}</Text>
          )}
        </View>
        <View style={{ flex: 1 }}>
          <Text style={styles.authorName}>
            {item.author?.displayName}
            {item.author?.isVerified ? ' ✓' : ''}
          </Text>
          <Text style={styles.date}>{new Date(item.createdAt).toLocaleString('es')}</Text>
        </View>
      </View>

      {!!item.content && <Text style={styles.content}>{item.content}</Text>}

      {item.mediaUrl ? (
        item.mediaType === 'video' ? (
          <View style={styles.videoPlaceholder}>
            <Text style={styles.videoText}>🎬 Video</Text>
          </View>
        ) : (
          <Image
            source={{ uri: getMediaUrl(item.mediaUrl) }}
            style={styles.postImage}
            resizeMode="cover"
          />
        )
      ) : null}
    </View>
  );

  if (loading) {
    return (
      <View style={styles.center}>
        <ActivityIndicator size="large" color="#ff6b9d" />
      </View>
    );
  }

  return (
    <View style={styles.container}>
      <View style={styles.composer}>
        <TextInput
          style={styles.composerInput}
          value={newPost}
          onChangeText={setNewPost}
          placeholder="¿Qué estás pensando?"
          placeholderTextColor="#666"
          multiline
        />
        {media && (
          <View style={styles.previewBox}>
            <Text style={styles.previewText}>
              {media.type === 'video' ? '🎬 Video seleccionado' : '🖼️ Foto seleccionada'}
            </Text>
            <TouchableOpacity onPress={() => setMedia(null)}>
              <Text style={styles.removeMedia}>✕</Text>
            </TouchableOpacity>
          </View>
        )}
        <View style={styles.composerActions}>
          <TouchableOpacity style={styles.attachBtn} onPress={pickMedia}>
            <Text style={styles.attachText}>📷 Foto / Video</Text>
          </TouchableOpacity>
          <TouchableOpacity
            style={[styles.postButton, posting && { opacity: 0.6 }]}
            onPress={handleCreatePost}
            disabled={posting}
          >
            {posting ? <ActivityIndicator color="#fff" size="small" /> : <Text style={styles.postButtonText}>Publicar</Text>}
          </TouchableOpacity>
        </View>
      </View>

      <FlatList
        data={posts}
        keyExtractor={(item) => item.id}
        renderItem={renderPost}
        contentContainerStyle={{ padding: 16, paddingBottom: 40 }}
        refreshControl={
          <RefreshControl
            refreshing={refreshing}
            onRefresh={() => { setRefreshing(true); loadFeed(); }}
            tintColor="#ff6b9d"
          />
        }
        ListEmptyComponent={
          <Text style={styles.empty}>Aún no hay publicaciones. ¡Sé el primero!</Text>
        }
      />
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: '#0f0f13' },
  center: { flex: 1, justifyContent: 'center', alignItems: 'center', backgroundColor: '#0f0f13' },
  composer: {
    backgroundColor: '#1a1a22', padding: 16, borderBottomWidth: 1, borderBottomColor: '#2a2a35'
  },
  composerInput: {
    backgroundColor: '#0f0f13', borderRadius: 12, padding: 14, color: '#e8e8ed',
    minHeight: 60, textAlignVertical: 'top', borderWidth: 1, borderColor: '#3a3a48', marginBottom: 10
  },
  previewBox: {
    flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center',
    backgroundColor: '#2a2a35', borderRadius: 8, padding: 10, marginBottom: 10
  },
  previewText: { color: '#e8e8ed', fontSize: 13 },
  removeMedia: { color: '#ff6b6b', fontSize: 16, fontWeight: 'bold' },
  composerActions: { flexDirection: 'row', gap: 10 },
  attachBtn: {
    flex: 1, backgroundColor: '#2a2a35', borderRadius: 10, paddingVertical: 12, alignItems: 'center'
  },
  attachText: { color: '#e8e8ed', fontSize: 13 },
  postButton: {
    flex: 1, backgroundColor: '#ff6b9d', borderRadius: 10, paddingVertical: 12, alignItems: 'center'
  },
  postButtonText: { color: '#fff', fontWeight: 'bold', fontSize: 15 },
  postCard: {
    backgroundColor: '#1a1a22', borderRadius: 14, padding: 16, marginBottom: 12,
    borderWidth: 1, borderColor: '#2a2a35'
  },
  postHeader: { flexDirection: 'row', alignItems: 'center', marginBottom: 12 },
  avatar: {
    width: 42, height: 42, borderRadius: 21, backgroundColor: '#ff6b9d',
    justifyContent: 'center', alignItems: 'center', marginRight: 12, overflow: 'hidden'
  },
  avatarImg: { width: 42, height: 42 },
  avatarText: { color: '#fff', fontWeight: 'bold', fontSize: 18 },
  authorName: { color: '#e8e8ed', fontWeight: '600', fontSize: 15 },
  date: { color: '#a0a0b0', fontSize: 12, marginTop: 2 },
  content: { color: '#e8e8ed', fontSize: 15, lineHeight: 22, marginBottom: 8 },
  postImage: { width: '100%', height: 220, borderRadius: 12, marginTop: 4 },
  videoPlaceholder: {
    height: 120, backgroundColor: '#2a2a35', borderRadius: 12,
    justifyContent: 'center', alignItems: 'center', marginTop: 4
  },
  videoText: { color: '#e8e8ed', fontSize: 16 },
  empty: { color: '#a0a0b0', textAlign: 'center', marginTop: 40, fontSize: 15 },
});
