import React from 'react';
import {
  View, Text, TouchableOpacity, StyleSheet, ScrollView, Alert, Image
} from 'react-native';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { getMediaUrl } from '../services/api';

export default function ProfileScreen({ user, onLogout, navigation }) {
  const handleLogout = () => {
    Alert.alert('Cerrar sesión', '¿Estás seguro?', [
      { text: 'Cancelar', style: 'cancel' },
      {
        text: 'Salir',
        style: 'destructive',
        onPress: async () => {
          await AsyncStorage.removeItem('token');
          onLogout();
        },
      },
    ]);
  };

  return (
    <ScrollView style={styles.container} contentContainerStyle={{ padding: 20, paddingBottom: 40 }}>
      <View style={styles.header}>
        <View style={styles.avatar}>
          {user?.avatarUrl ? (
            <Image source={{ uri: getMediaUrl(user.avatarUrl) }} style={styles.avatarImg} />
          ) : (
            <Text style={styles.avatarText}>{user?.displayName?.[0]?.toUpperCase() || '?'}</Text>
          )}
        </View>
        <Text style={styles.name}>{user?.displayName}</Text>
        {user?.isVerified && <Text style={styles.verified}>✓ Perfil verificado</Text>}
        {user?.bio ? <Text style={styles.bio}>{user.bio}</Text> : null}
      </View>

      <View style={styles.card}>
        <InfoRow label="Email" value={user?.email} />
        <InfoRow label="Ciudad" value={user?.city || '—'} />
        <InfoRow label="País" value={user?.country || '—'} />
        <InfoRow
          label="Estado"
          value={
            user?.relationshipStatus === 'single' ? 'Soltero/a' :
            user?.relationshipStatus === 'couple' ? 'Pareja' :
            user?.relationshipStatus === 'open' ? 'Relación abierta' :
            user?.relationshipStatus || '—'
          }
        />
        {user?.lookingFor ? <InfoRow label="Busca" value={user.lookingFor} /> : null}
        {user?.orientation ? <InfoRow label="Orientación" value={user.orientation} /> : null}
      </View>

      <TouchableOpacity
        style={styles.editBtn}
        onPress={() => navigation.navigate('EditProfile')}
      >
        <Text style={styles.editText}>✏️ Editar perfil</Text>
      </TouchableOpacity>

      <TouchableOpacity style={styles.logoutBtn} onPress={handleLogout}>
        <Text style={styles.logoutText}>Cerrar sesión</Text>
      </TouchableOpacity>
    </ScrollView>
  );
}

function InfoRow({ label, value }) {
  return (
    <View style={styles.row}>
      <Text style={styles.label}>{label}</Text>
      <Text style={styles.value} numberOfLines={2}>{value}</Text>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: '#0f0f13' },
  header: { alignItems: 'center', marginBottom: 24, marginTop: 10 },
  avatar: {
    width: 90, height: 90, borderRadius: 45, backgroundColor: '#ff6b9d',
    justifyContent: 'center', alignItems: 'center', marginBottom: 12, overflow: 'hidden'
  },
  avatarImg: { width: 90, height: 90 },
  avatarText: { color: '#fff', fontSize: 34, fontWeight: 'bold' },
  name: { color: '#e8e8ed', fontSize: 22, fontWeight: 'bold' },
  verified: { color: '#51cf66', marginTop: 4, fontSize: 14 },
  bio: { color: '#a0a0b0', marginTop: 10, textAlign: 'center', paddingHorizontal: 20, lineHeight: 20 },
  card: {
    backgroundColor: '#1a1a22', borderRadius: 14, padding: 16,
    borderWidth: 1, borderColor: '#2a2a35'
  },
  row: {
    flexDirection: 'row', justifyContent: 'space-between', paddingVertical: 12,
    borderBottomWidth: 1, borderBottomColor: '#2a2a35'
  },
  label: { color: '#a0a0b0', fontSize: 14 },
  value: { color: '#e8e8ed', fontSize: 14, fontWeight: '500', maxWidth: '60%', textAlign: 'right' },
  editBtn: {
    marginTop: 20, backgroundColor: '#2a2a35', borderRadius: 12, padding: 16, alignItems: 'center'
  },
  editText: { color: '#ff6b9d', fontWeight: 'bold', fontSize: 15 },
  logoutBtn: {
    marginTop: 12, backgroundColor: '#2a2a35', borderRadius: 12, padding: 16, alignItems: 'center'
  },
  logoutText: { color: '#ff6b6b', fontWeight: 'bold', fontSize: 16 },
});
