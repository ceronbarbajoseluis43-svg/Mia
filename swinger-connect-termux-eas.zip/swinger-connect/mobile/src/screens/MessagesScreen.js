import React, { useState, useCallback } from 'react';
import {
  View, Text, FlatList, TouchableOpacity, StyleSheet,
  ActivityIndicator, RefreshControl, Image
} from 'react-native';
import { useFocusEffect } from '@react-navigation/native';
import { messagesAPI, getMediaUrl } from '../services/api';

export default function MessagesScreen({ navigation }) {
  const [conversations, setConversations] = useState([]);
  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);

  const load = useCallback(async () => {
    try {
      const { data } = await messagesAPI.list();
      setConversations(data.conversations || []);
    } catch (e) {
      console.log(e);
    } finally {
      setLoading(false);
      setRefreshing(false);
    }
  }, []);

  useFocusEffect(
    useCallback(() => {
      load();
    }, [load])
  );

  const renderItem = ({ item }) => {
    const u = item.otherUser;
    return (
      <TouchableOpacity
        style={styles.row}
        onPress={() => navigation.navigate('Chat', { userId: u.id, userName: u.displayName, avatarUrl: u.avatarUrl })}
      >
        <View style={styles.avatar}>
          {u.avatarUrl ? (
            <Image source={{ uri: getMediaUrl(u.avatarUrl) }} style={styles.avatarImg} />
          ) : (
            <Text style={styles.avatarLetter}>{u.displayName?.[0]?.toUpperCase()}</Text>
          )}
        </View>
        <View style={{ flex: 1 }}>
          <Text style={styles.name}>{u.displayName}</Text>
          <Text style={styles.preview} numberOfLines={1}>
            {item.lastMessage?.mediaType ? '📎 Media' : item.lastMessage?.content || ''}
          </Text>
        </View>
        {item.unreadCount > 0 && (
          <View style={styles.badge}>
            <Text style={styles.badgeText}>{item.unreadCount}</Text>
          </View>
        )}
      </TouchableOpacity>
    );
  };

  if (loading) {
    return (
      <View style={styles.center}>
        <ActivityIndicator size="large" color="#ff6b9d" />
      </View>
    );
  }

  return (
    <View style={styles.container}>
      <FlatList
        data={conversations}
        keyExtractor={(item) => item.otherUser.id}
        renderItem={renderItem}
        contentContainerStyle={{ padding: 16 }}
        refreshControl={
          <RefreshControl refreshing={refreshing} onRefresh={() => { setRefreshing(true); load(); }} tintColor="#ff6b9d" />
        }
        ListEmptyComponent={
          <Text style={styles.empty}>Aún no tienes conversaciones. Conecta con alguien y envíale un mensaje.</Text>
        }
      />
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: '#0f0f13' },
  center: { flex: 1, justifyContent: 'center', alignItems: 'center', backgroundColor: '#0f0f13' },
  row: {
    flexDirection: 'row', alignItems: 'center', backgroundColor: '#1a1a22',
    borderRadius: 14, padding: 14, marginBottom: 10, borderWidth: 1, borderColor: '#2a2a35'
  },
  avatar: {
    width: 50, height: 50, borderRadius: 25, backgroundColor: '#ff6b9d',
    justifyContent: 'center', alignItems: 'center', marginRight: 12, overflow: 'hidden'
  },
  avatarImg: { width: 50, height: 50 },
  avatarLetter: { color: '#fff', fontWeight: 'bold', fontSize: 18 },
  name: { color: '#e8e8ed', fontWeight: '600', fontSize: 16 },
  preview: { color: '#a0a0b0', fontSize: 13, marginTop: 3 },
  badge: {
    backgroundColor: '#ff6b9d', borderRadius: 12, minWidth: 24, height: 24,
    justifyContent: 'center', alignItems: 'center', paddingHorizontal: 6
  },
  badgeText: { color: '#fff', fontSize: 12, fontWeight: 'bold' },
  empty: { color: '#a0a0b0', textAlign: 'center', marginTop: 40, paddingHorizontal: 20 },
});
