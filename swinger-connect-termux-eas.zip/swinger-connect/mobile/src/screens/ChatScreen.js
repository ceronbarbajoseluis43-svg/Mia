import React, { useState, useEffect, useRef } from 'react';
import {
  View, Text, TextInput, TouchableOpacity, StyleSheet, FlatList,
  KeyboardAvoidingView, Platform, ActivityIndicator, Alert, Image
} from 'react-native';
import * as ImagePicker from 'expo-image-picker';
import { messagesAPI, uploadAPI, getMediaUrl } from '../services/api';

export default function ChatScreen({ route }) {
  const { userId, userName } = route.params;
  const [messages, setMessages] = useState([]);
  const [text, setText] = useState('');
  const [loading, setLoading] = useState(true);
  const [sending, setSending] = useState(false);
  const [myId, setMyId] = useState(null);
  const listRef = useRef(null);

  useEffect(() => {
    loadMessages();
    const interval = setInterval(loadMessages, 8000);
    return () => clearInterval(interval);
  }, [userId]);

  const loadMessages = async () => {
    try {
      const { data } = await messagesAPI.conversation(userId);
      setMessages(data.messages || []);
      if (data.messages?.length > 0) {
        // Detectar mi id del primer mensaje propio
        // Lo hacemos de forma simple
      }
    } catch (e) {
      console.log(e);
    } finally {
      setLoading(false);
    }
  };

  const send = async (mediaUrl = null, mediaType = null) => {
    if (!text.trim() && !mediaUrl) return;
    setSending(true);
    try {
      await messagesAPI.send({
        receiverId: userId,
        content: text.trim(),
        mediaUrl,
        mediaType,
      });
      setText('');
      await loadMessages();
      setTimeout(() => listRef.current?.scrollToEnd?.({ animated: true }), 200);
    } catch (err) {
      Alert.alert('Error', err.response?.data?.error || 'No se pudo enviar');
    } finally {
      setSending(false);
    }
  };

  const pickMedia = async () => {
    const { status } = await ImagePicker.requestMediaLibraryPermissionsAsync();
    if (status !== 'granted') {
      Alert.alert('Permiso necesario', 'Necesitamos acceso a la galería');
      return;
    }
    const result = await ImagePicker.launchImageLibraryAsync({
      mediaTypes: ImagePicker.MediaTypeOptions.All,
      quality: 0.8,
    });
    if (!result.canceled && result.assets[0]) {
      const asset = result.assets[0];
      setSending(true);
      try {
        const isVideo = asset.type === 'video';
        const data = await uploadAPI.upload(
          asset.uri,
          isVideo ? 'video/mp4' : 'image/jpeg'
        );
        await send(data.mediaUrl, data.mediaType);
      } catch (err) {
        Alert.alert('Error', err.message || 'No se pudo subir');
        setSending(false);
      }
    }
  };

  const renderMsg = ({ item }) => {
    // Heurística: si el sender soy yo (comparando con el userId del chat)
    const isMe = item.senderId !== userId;
    return (
      <View style={[styles.bubble, isMe ? styles.bubbleMe : styles.bubbleOther]}>
        {item.mediaUrl ? (
          item.mediaType === 'video' ? (
            <Text style={styles.mediaLabel}>🎬 Video</Text>
          ) : (
            <Image
              source={{ uri: getMediaUrl(item.mediaUrl) }}
              style={styles.media}
              resizeMode="cover"
            />
          )
        ) : null}
        {!!item.content && (
          <Text style={[styles.msgText, isMe && styles.msgTextMe]}>{item.content}</Text>
        )}
        <Text style={styles.time}>
          {new Date(item.createdAt).toLocaleTimeString('es', { hour: '2-digit', minute: '2-digit' })}
        </Text>
      </View>
    );
  };

  if (loading) {
    return (
      <View style={styles.center}>
        <ActivityIndicator size="large" color="#ff6b9d" />
      </View>
    );
  }

  return (
    <KeyboardAvoidingView
      style={styles.container}
      behavior={Platform.OS === 'ios' ? 'padding' : undefined}
      keyboardVerticalOffset={90}
    >
      <FlatList
        ref={listRef}
        data={messages}
        keyExtractor={(item) => item.id}
        renderItem={renderMsg}
        contentContainerStyle={{ padding: 16, paddingBottom: 8 }}
        onContentSizeChange={() => listRef.current?.scrollToEnd?.({ animated: false })}
      />

      <View style={styles.inputBar}>
        <TouchableOpacity style={styles.attachBtn} onPress={pickMedia} disabled={sending}>
          <Text style={styles.attachText}>📎</Text>
        </TouchableOpacity>
        <TextInput
          style={styles.input}
          value={text}
          onChangeText={setText}
          placeholder="Escribe un mensaje..."
          placeholderTextColor="#666"
          multiline
        />
        <TouchableOpacity
          style={[styles.sendBtn, sending && { opacity: 0.5 }]}
          onPress={() => send()}
          disabled={sending}
        >
          {sending ? <ActivityIndicator color="#fff" size="small" /> : <Text style={styles.sendText}>➤</Text>}
        </TouchableOpacity>
      </View>
    </KeyboardAvoidingView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: '#0f0f13' },
  center: { flex: 1, justifyContent: 'center', alignItems: 'center', backgroundColor: '#0f0f13' },
  bubble: {
    maxWidth: '80%', borderRadius: 16, padding: 12, marginBottom: 8
  },
  bubbleMe: {
    alignSelf: 'flex-end', backgroundColor: '#ff6b9d', borderBottomRightRadius: 4
  },
  bubbleOther: {
    alignSelf: 'flex-start', backgroundColor: '#1a1a22', borderBottomLeftRadius: 4, borderWidth: 1, borderColor: '#2a2a35'
  },
  msgText: { color: '#e8e8ed', fontSize: 15, lineHeight: 20 },
  msgTextMe: { color: '#fff' },
  time: { fontSize: 10, color: 'rgba(255,255,255,0.6)', marginTop: 4, alignSelf: 'flex-end' },
  media: { width: 200, height: 150, borderRadius: 10, marginBottom: 6 },
  mediaLabel: { color: '#fff', marginBottom: 4 },
  inputBar: {
    flexDirection: 'row', alignItems: 'flex-end', padding: 10,
    backgroundColor: '#1a1a22', borderTopWidth: 1, borderTopColor: '#2a2a35'
  },
  attachBtn: { padding: 10 },
  attachText: { fontSize: 22 },
  input: {
    flex: 1, backgroundColor: '#0f0f13', borderRadius: 20, paddingHorizontal: 14,
    paddingVertical: 10, color: '#e8e8ed', maxHeight: 100, borderWidth: 1, borderColor: '#3a3a48'
  },
  sendBtn: {
    backgroundColor: '#ff6b9d', width: 42, height: 42, borderRadius: 21,
    justifyContent: 'center', alignItems: 'center', marginLeft: 8
  },
  sendText: { color: '#fff', fontSize: 18 },
});
