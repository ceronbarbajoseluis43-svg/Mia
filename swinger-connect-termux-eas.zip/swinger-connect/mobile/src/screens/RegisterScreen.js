import React, { useState } from 'react';
import {
  View,
  Text,
  TextInput,
  TouchableOpacity,
  StyleSheet,
  KeyboardAvoidingView,
  Platform,
  ScrollView,
  Alert,
  ActivityIndicator,
} from 'react-native';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { authAPI } from '../services/api';

export default function RegisterScreen({ navigation, onLogin }) {
  const [form, setForm] = useState({
    displayName: '',
    email: '',
    password: '',
    birthDate: '',
    relationshipStatus: 'single',
    city: '',
    country: '',
  });
  const [loading, setLoading] = useState(false);

  const update = (key, value) => setForm({ ...form, [key]: value });

  const handleRegister = async () => {
    if (!form.displayName || !form.email || !form.password || !form.birthDate) {
      Alert.alert('Error', 'Completa los campos obligatorios (*)');
      return;
    }

    if (form.password.length < 8) {
      Alert.alert('Error', 'La contraseña debe tener al menos 8 caracteres');
      return;
    }

    // Validación básica de fecha (YYYY-MM-DD)
    if (!/^\d{4}-\d{2}-\d{2}$/.test(form.birthDate)) {
      Alert.alert('Error', 'Fecha de nacimiento debe ser en formato AAAA-MM-DD\nEjemplo: 1990-05-15');
      return;
    }

    setLoading(true);
    try {
      const { data } = await authAPI.register(form);
      await AsyncStorage.setItem('token', data.token);
      onLogin(data.user);
    } catch (err) {
      const message = err.response?.data?.error || 'Error en el registro';
      Alert.alert('Error', message);
    } finally {
      setLoading(false);
    }
  };

  return (
    <KeyboardAvoidingView
      style={styles.container}
      behavior={Platform.OS === 'ios' ? 'padding' : undefined}
    >
      <ScrollView contentContainerStyle={styles.scroll}>
        <Text style={styles.title}>Crear cuenta</Text>
        <Text style={styles.subtitle}>Solo mayores de 18 años</Text>

        <View style={styles.card}>
          <Text style={styles.label}>Nombre visible *</Text>
          <TextInput
            style={styles.input}
            value={form.displayName}
            onChangeText={(v) => update('displayName', v)}
            placeholder="Ej: Alex & Sam"
            placeholderTextColor="#666"
          />

          <Text style={styles.label}>Email *</Text>
          <TextInput
            style={styles.input}
            value={form.email}
            onChangeText={(v) => update('email', v)}
            keyboardType="email-address"
            autoCapitalize="none"
            placeholder="tu@email.com"
            placeholderTextColor="#666"
          />

          <Text style={styles.label}>Contraseña * (mín. 8)</Text>
          <TextInput
            style={styles.input}
            value={form.password}
            onChangeText={(v) => update('password', v)}
            secureTextEntry
            placeholder="••••••••"
            placeholderTextColor="#666"
          />

          <Text style={styles.label}>Fecha de nacimiento * (AAAA-MM-DD)</Text>
          <TextInput
            style={styles.input}
            value={form.birthDate}
            onChangeText={(v) => update('birthDate', v)}
            placeholder="1990-05-15"
            placeholderTextColor="#666"
            keyboardType="numbers-and-punctuation"
          />

          <Text style={styles.label}>Estado de relación</Text>
          <View style={styles.optionsRow}>
            {['single', 'couple', 'open', 'married'].map((opt) => (
              <TouchableOpacity
                key={opt}
                style={[
                  styles.option,
                  form.relationshipStatus === opt && styles.optionActive,
                ]}
                onPress={() => update('relationshipStatus', opt)}
              >
                <Text
                  style={[
                    styles.optionText,
                    form.relationshipStatus === opt && styles.optionTextActive,
                  ]}
                >
                  {opt === 'single' ? 'Soltero/a' :
                   opt === 'couple' ? 'Pareja' :
                   opt === 'open' ? 'Abierta' : 'Casados'}
                </Text>
              </TouchableOpacity>
            ))}
          </View>

          <Text style={styles.label}>Ciudad</Text>
          <TextInput
            style={styles.input}
            value={form.city}
            onChangeText={(v) => update('city', v)}
            placeholder="Madrid"
            placeholderTextColor="#666"
          />

          <Text style={styles.label}>País</Text>
          <TextInput
            style={styles.input}
            value={form.country}
            onChangeText={(v) => update('country', v)}
            placeholder="España"
            placeholderTextColor="#666"
          />

          <TouchableOpacity
            style={[styles.button, loading && styles.buttonDisabled]}
            onPress={handleRegister}
            disabled={loading}
          >
            {loading ? (
              <ActivityIndicator color="#fff" />
            ) : (
              <Text style={styles.buttonText}>Crear cuenta (18+)</Text>
            )}
          </TouchableOpacity>

          <TouchableOpacity
            style={styles.linkButton}
            onPress={() => navigation.goBack()}
          >
            <Text style={styles.linkText}>
              ¿Ya tienes cuenta? <Text style={styles.linkBold}>Inicia sesión</Text>
            </Text>
          </TouchableOpacity>
        </View>
      </ScrollView>
    </KeyboardAvoidingView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#0f0f13',
  },
  scroll: {
    flexGrow: 1,
    padding: 24,
    paddingTop: 60,
  },
  title: {
    fontSize: 26,
    fontWeight: 'bold',
    color: '#e8e8ed',
    textAlign: 'center',
  },
  subtitle: {
    fontSize: 14,
    color: '#a0a0b0',
    textAlign: 'center',
    marginBottom: 24,
  },
  card: {
    backgroundColor: '#1a1a22',
    borderRadius: 16,
    padding: 20,
    borderWidth: 1,
    borderColor: '#2a2a35',
  },
  label: {
    color: '#a0a0b0',
    fontSize: 13,
    marginBottom: 6,
    marginTop: 12,
  },
  input: {
    backgroundColor: '#0f0f13',
    borderRadius: 10,
    padding: 14,
    color: '#e8e8ed',
    borderWidth: 1,
    borderColor: '#3a3a48',
    fontSize: 16,
  },
  optionsRow: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    gap: 8,
    marginTop: 4,
  },
  option: {
    paddingVertical: 8,
    paddingHorizontal: 12,
    borderRadius: 20,
    backgroundColor: '#2a2a35',
  },
  optionActive: {
    backgroundColor: '#ff6b9d',
  },
  optionText: {
    color: '#a0a0b0',
    fontSize: 13,
  },
  optionTextActive: {
    color: '#fff',
    fontWeight: '600',
  },
  button: {
    backgroundColor: '#ff6b9d',
    borderRadius: 10,
    padding: 16,
    alignItems: 'center',
    marginTop: 24,
  },
  buttonDisabled: {
    opacity: 0.6,
  },
  buttonText: {
    color: '#fff',
    fontWeight: 'bold',
    fontSize: 16,
  },
  linkButton: {
    marginTop: 20,
    alignItems: 'center',
  },
  linkText: {
    color: '#a0a0b0',
    fontSize: 14,
  },
  linkBold: {
    color: '#ff6b9d',
    fontWeight: 'bold',
  },
});
