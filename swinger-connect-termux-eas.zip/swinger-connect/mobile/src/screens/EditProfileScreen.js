import React, { useState, useEffect } from 'react';
import {
  View, Text, TextInput, TouchableOpacity, StyleSheet,
  ScrollView, Alert, ActivityIndicator, Image
} from 'react-native';
import * as ImagePicker from 'expo-image-picker';
import { usersAPI, uploadAPI, getMediaUrl } from '../services/api';

export default function EditProfileScreen({ navigation, user, onUpdate }) {
  const [form, setForm] = useState({
    displayName: '',
    bio: '',
    gender: '',
    orientation: '',
    relationshipStatus: 'single',
    lookingFor: '',
    preferences: '',
    city: '',
    country: '',
    avatarUrl: '',
  });
  const [loading, setLoading] = useState(false);
  const [uploading, setUploading] = useState(false);

  useEffect(() => {
    if (user) {
      setForm({
        displayName: user.displayName || '',
        bio: user.bio || '',
        gender: user.gender || '',
        orientation: user.orientation || '',
        relationshipStatus: user.relationshipStatus || 'single',
        lookingFor: user.lookingFor || '',
        preferences: user.preferences || '',
        city: user.city || '',
        country: user.country || '',
        avatarUrl: user.avatarUrl || '',
      });
    }
  }, [user]);

  const update = (key, value) => setForm(prev => ({ ...prev, [key]: value }));

  const pickAvatar = async () => {
    const { status } = await ImagePicker.requestMediaLibraryPermissionsAsync();
    if (status !== 'granted') {
      Alert.alert('Permiso necesario', 'Necesitamos acceso a tu galería');
      return;
    }

    const result = await ImagePicker.launchImageLibraryAsync({
      mediaTypes: ImagePicker.MediaTypeOptions.Images,
      allowsEditing: true,
      aspect: [1, 1],
      quality: 0.8,
    });

    if (!result.canceled && result.assets[0]) {
      setUploading(true);
      try {
        const data = await uploadAPI.upload(result.assets[0].uri, 'image/jpeg');
        update('avatarUrl', data.mediaUrl);
        Alert.alert('Éxito', 'Foto subida. Guarda los cambios.');
      } catch (err) {
        Alert.alert('Error', err.message || 'No se pudo subir la foto');
      } finally {
        setUploading(false);
      }
    }
  };

  const handleSave = async () => {
    if (!form.displayName.trim()) {
      Alert.alert('Error', 'El nombre es obligatorio');
      return;
    }
    setLoading(true);
    try {
      const { data } = await usersAPI.updateMe(form);
      onUpdate?.(data.user);
      Alert.alert('Guardado', 'Perfil actualizado correctamente', [
        { text: 'OK', onPress: () => navigation.goBack() }
      ]);
    } catch (err) {
      Alert.alert('Error', err.response?.data?.error || 'No se pudo guardar');
    } finally {
      setLoading(false);
    }
  };

  return (
    <ScrollView style={styles.container} contentContainerStyle={{ padding: 20, paddingBottom: 40 }}>
      <Text style={styles.title}>Editar perfil</Text>

      <TouchableOpacity style={styles.avatarBox} onPress={pickAvatar} disabled={uploading}>
        {form.avatarUrl ? (
          <Image source={{ uri: getMediaUrl(form.avatarUrl) }} style={styles.avatarImg} />
        ) : (
          <View style={styles.avatarPlaceholder}>
            <Text style={styles.avatarLetter}>{form.displayName?.[0]?.toUpperCase() || '?'}</Text>
          </View>
        )}
        <Text style={styles.changePhoto}>{uploading ? 'Subiendo...' : 'Cambiar foto'}</Text>
      </TouchableOpacity>

      <Text style={styles.label}>Nombre visible *</Text>
      <TextInput style={styles.input} value={form.displayName} onChangeText={v => update('displayName', v)} />

      <Text style={styles.label}>Bio</Text>
      <TextInput
        style={[styles.input, { height: 90, textAlignVertical: 'top' }]}
        value={form.bio}
        onChangeText={v => update('bio', v)}
        multiline
        placeholder="Cuéntanos sobre ti..."
        placeholderTextColor="#666"
      />

      <Text style={styles.label}>Estado de relación</Text>
      <View style={styles.optionsRow}>
        {[
          { k: 'single', l: 'Soltero/a' },
          { k: 'couple', l: 'Pareja' },
          { k: 'open', l: 'Abierta' },
          { k: 'married', l: 'Casados' },
        ].map(o => (
          <TouchableOpacity
            key={o.k}
            style={[styles.option, form.relationshipStatus === o.k && styles.optionActive]}
            onPress={() => update('relationshipStatus', o.k)}
          >
            <Text style={[styles.optionText, form.relationshipStatus === o.k && styles.optionTextActive]}>
              {o.l}
            </Text>
          </TouchableOpacity>
        ))}
      </View>

      <Text style={styles.label}>Género</Text>
      <TextInput style={styles.input} value={form.gender} onChangeText={v => update('gender', v)} placeholder="male / female / couple / other" placeholderTextColor="#666" />

      <Text style={styles.label}>Orientación</Text>
      <TextInput style={styles.input} value={form.orientation} onChangeText={v => update('orientation', v)} placeholder="heterosexual, bisexual..." placeholderTextColor="#666" />

      <Text style={styles.label}>Busco (looking for)</Text>
      <TextInput
        style={[styles.input, { height: 70, textAlignVertical: 'top' }]}
        value={form.lookingFor}
        onChangeText={v => update('lookingFor', v)}
        multiline
        placeholder="soft swap, full swap, voyeur, fiestas..."
        placeholderTextColor="#666"
      />

      <Text style={styles.label}>Preferencias</Text>
      <TextInput
        style={[styles.input, { height: 70, textAlignVertical: 'top' }]}
        value={form.preferences}
        onChangeText={v => update('preferences', v)}
        multiline
        placeholderTextColor="#666"
      />

      <Text style={styles.label}>Ciudad</Text>
      <TextInput style={styles.input} value={form.city} onChangeText={v => update('city', v)} />

      <Text style={styles.label}>País</Text>
      <TextInput style={styles.input} value={form.country} onChangeText={v => update('country', v)} />

      <TouchableOpacity style={[styles.saveBtn, loading && { opacity: 0.6 }]} onPress={handleSave} disabled={loading}>
        {loading ? <ActivityIndicator color="#fff" /> : <Text style={styles.saveText}>Guardar cambios</Text>}
      </TouchableOpacity>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: '#0f0f13' },
  title: { fontSize: 22, fontWeight: 'bold', color: '#e8e8ed', marginBottom: 20 },
  avatarBox: { alignItems: 'center', marginBottom: 20 },
  avatarImg: { width: 100, height: 100, borderRadius: 50 },
  avatarPlaceholder: {
    width: 100, height: 100, borderRadius: 50, backgroundColor: '#ff6b9d',
    justifyContent: 'center', alignItems: 'center'
  },
  avatarLetter: { color: '#fff', fontSize: 36, fontWeight: 'bold' },
  changePhoto: { color: '#ff6b9d', marginTop: 8, fontWeight: '600' },
  label: { color: '#a0a0b0', fontSize: 13, marginBottom: 6, marginTop: 12 },
  input: {
    backgroundColor: '#1a1a22', borderRadius: 10, padding: 14, color: '#e8e8ed',
    borderWidth: 1, borderColor: '#3a3a48', fontSize: 15
  },
  optionsRow: { flexDirection: 'row', flexWrap: 'wrap', gap: 8 },
  option: { paddingVertical: 8, paddingHorizontal: 14, borderRadius: 20, backgroundColor: '#2a2a35' },
  optionActive: { backgroundColor: '#ff6b9d' },
  optionText: { color: '#a0a0b0', fontSize: 13 },
  optionTextActive: { color: '#fff', fontWeight: '600' },
  saveBtn: {
    backgroundColor: '#ff6b9d', borderRadius: 12, padding: 16,
    alignItems: 'center', marginTop: 28
  },
  saveText: { color: '#fff', fontWeight: 'bold', fontSize: 16 },
});
