import React, { useState } from 'react';
import {
  View,
  Text,
  TextInput,
  TouchableOpacity,
  StyleSheet,
  FlatList,
  ActivityIndicator,
  Alert,
} from 'react-native';
import { usersAPI, friendshipsAPI } from '../services/api';

export default function SearchScreen() {
  const [query, setQuery] = useState('');
  const [results, setResults] = useState([]);
  const [loading, setLoading] = useState(false);

  const handleSearch = async () => {
    if (!query.trim()) return;
    setLoading(true);
    try {
      const { data } = await usersAPI.search({ q: query.trim() });
      setResults(data.users || []);
    } catch (err) {
      Alert.alert('Error', 'No se pudo realizar la búsqueda');
    } finally {
      setLoading(false);
    }
  };

  const sendRequest = async (userId, name) => {
    try {
      await friendshipsAPI.request(userId);
      Alert.alert('Éxito', `Solicitud enviada a ${name}`);
    } catch (err) {
      const msg = err.response?.data?.error || 'No se pudo enviar la solicitud';
      Alert.alert('Info', msg);
    }
  };

  const renderUser = ({ item }) => (
    <View style={styles.userCard}>
      <View style={styles.avatar}>
        <Text style={styles.avatarText}>
          {item.displayName?.[0]?.toUpperCase() || '?'}
        </Text>
      </View>
      <View style={{ flex: 1 }}>
        <Text style={styles.name}>
          {item.displayName}
          {item.isVerified ? ' ✓' : ''}
        </Text>
        <Text style={styles.meta}>
          {item.relationshipStatus || ''}
          {item.city ? ` · ${item.city}` : ''}
        </Text>
        {item.lookingFor ? (
          <Text style={styles.looking}>Busca: {item.lookingFor}</Text>
        ) : null}
      </View>
      <TouchableOpacity
        style={styles.connectBtn}
        onPress={() => sendRequest(item.id, item.displayName)}
      >
        <Text style={styles.connectText}>Conectar</Text>
      </TouchableOpacity>
    </View>
  );

  return (
    <View style={styles.container}>
      <View style={styles.searchBar}>
        <TextInput
          style={styles.input}
          value={query}
          onChangeText={setQuery}
          placeholder="Buscar por nombre o ciudad..."
          placeholderTextColor="#666"
          onSubmitEditing={handleSearch}
          returnKeyType="search"
        />
        <TouchableOpacity style={styles.searchBtn} onPress={handleSearch}>
          {loading ? (
            <ActivityIndicator color="#fff" size="small" />
          ) : (
            <Text style={styles.searchBtnText}>Buscar</Text>
          )}
        </TouchableOpacity>
      </View>

      <FlatList
        data={results}
        keyExtractor={(item) => item.id}
        renderItem={renderUser}
        contentContainerStyle={{ padding: 16 }}
        ListEmptyComponent={
          <Text style={styles.empty}>
            {query ? 'No se encontraron resultados' : 'Escribe algo para buscar'}
          </Text>
        }
      />
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#0f0f13',
  },
  searchBar: {
    flexDirection: 'row',
    padding: 16,
    gap: 10,
    backgroundColor: '#1a1a22',
    borderBottomWidth: 1,
    borderBottomColor: '#2a2a35',
  },
  input: {
    flex: 1,
    backgroundColor: '#0f0f13',
    borderRadius: 10,
    paddingHorizontal: 14,
    paddingVertical: 12,
    color: '#e8e8ed',
    borderWidth: 1,
    borderColor: '#3a3a48',
  },
  searchBtn: {
    backgroundColor: '#ff6b9d',
    borderRadius: 10,
    paddingHorizontal: 18,
    justifyContent: 'center',
  },
  searchBtnText: {
    color: '#fff',
    fontWeight: 'bold',
  },
  userCard: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#1a1a22',
    borderRadius: 14,
    padding: 14,
    marginBottom: 10,
    borderWidth: 1,
    borderColor: '#2a2a35',
  },
  avatar: {
    width: 48,
    height: 48,
    borderRadius: 24,
    backgroundColor: '#ff6b9d',
    justifyContent: 'center',
    alignItems: 'center',
    marginRight: 12,
  },
  avatarText: {
    color: '#fff',
    fontWeight: 'bold',
    fontSize: 18,
  },
  name: {
    color: '#e8e8ed',
    fontWeight: '600',
    fontSize: 16,
  },
  meta: {
    color: '#a0a0b0',
    fontSize: 13,
    marginTop: 2,
  },
  looking: {
    color: '#ff6b9d',
    fontSize: 12,
    marginTop: 4,
  },
  connectBtn: {
    backgroundColor: '#2a2a35',
    paddingVertical: 8,
    paddingHorizontal: 14,
    borderRadius: 20,
  },
  connectText: {
    color: '#ff6b9d',
    fontWeight: '600',
    fontSize: 13,
  },
  empty: {
    color: '#a0a0b0',
    textAlign: 'center',
    marginTop: 40,
  },
});
