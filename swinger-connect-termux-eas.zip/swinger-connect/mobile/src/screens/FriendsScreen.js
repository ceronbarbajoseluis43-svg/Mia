import React, { useState, useCallback } from 'react';
import {
  View, Text, FlatList, TouchableOpacity, StyleSheet,
  ActivityIndicator, RefreshControl, Alert, Image
} from 'react-native';
import { useFocusEffect } from '@react-navigation/native';
import { friendshipsAPI, getMediaUrl } from '../services/api';

export default function FriendsScreen({ navigation }) {
  const [connections, setConnections] = useState([]);
  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);

  const load = useCallback(async () => {
    try {
      const { data } = await friendshipsAPI.list();
      setConnections(data.connections || []);
    } catch (e) {
      console.log(e);
    } finally {
      setLoading(false);
      setRefreshing(false);
    }
  }, []);

  useFocusEffect(useCallback(() => { load(); }, [load]));

  const accept = async (id) => {
    try {
      await friendshipsAPI.accept(id);
      load();
      Alert.alert('Conexión aceptada');
    } catch (e) {
      Alert.alert('Error', 'No se pudo aceptar');
    }
  };

  const reject = async (id) => {
    try {
      await friendshipsAPI.reject(id);
      load();
    } catch (e) {
      Alert.alert('Error', 'No se pudo rechazar');
    }
  };

  const renderItem = ({ item }) => {
    const u = item.otherUser;
    return (
      <View style={styles.card}>
        <View style={styles.avatar}>
          {u.avatarUrl ? (
            <Image source={{ uri: getMediaUrl(u.avatarUrl) }} style={styles.avatarImg} />
          ) : (
            <Text style={styles.avatarLetter}>{u.displayName?.[0]?.toUpperCase()}</Text>
          )}
        </View>
        <View style={{ flex: 1 }}>
          <Text style={styles.name}>{u.displayName}</Text>
          <Text style={styles.meta}>
            {u.relationshipStatus || ''} {u.city ? `· ${u.city}` : ''}
          </Text>
          <Text style={styles.status}>
            {item.isIncoming ? '📩 Solicitud recibida' :
             item.isOutgoing ? '⏳ Solicitud enviada' :
             item.status === 'accepted' ? '✅ Conectados' : item.status}
          </Text>
        </View>
        <View>
          {item.isIncoming && (
            <>
              <TouchableOpacity style={styles.acceptBtn} onPress={() => accept(item.id)}>
                <Text style={styles.acceptText}>Aceptar</Text>
              </TouchableOpacity>
              <TouchableOpacity style={styles.rejectBtn} onPress={() => reject(item.id)}>
                <Text style={styles.rejectText}>Rechazar</Text>
              </TouchableOpacity>
            </>
          )}
          {item.status === 'accepted' && (
            <TouchableOpacity
              style={styles.msgBtn}
              onPress={() => navigation.navigate('Chat', {
                userId: u.id,
                userName: u.displayName,
                avatarUrl: u.avatarUrl
              })}
            >
              <Text style={styles.msgText}>Mensaje</Text>
            </TouchableOpacity>
          )}
        </View>
      </View>
    );
  };

  if (loading) {
    return (
      <View style={styles.center}>
        <ActivityIndicator size="large" color="#ff6b9d" />
      </View>
    );
  }

  const incoming = connections.filter(c => c.isIncoming);
  const accepted = connections.filter(c => c.status === 'accepted');
  const outgoing = connections.filter(c => c.isOutgoing);

  return (
    <View style={styles.container}>
      <FlatList
        data={[
          ...(incoming.length ? [{ type: 'header', title: 'Solicitudes recibidas' }] : []),
          ...incoming,
          ...(accepted.length ? [{ type: 'header', title: 'Mis conexiones' }] : []),
          ...accepted,
          ...(outgoing.length ? [{ type: 'header', title: 'Enviadas' }] : []),
          ...outgoing,
        ]}
        keyExtractor={(item, i) => item.id || `h-${i}`}
        renderItem={({ item }) => {
          if (item.type === 'header') {
            return <Text style={styles.section}>{item.title}</Text>;
          }
          return renderItem({ item });
        }}
        contentContainerStyle={{ padding: 16 }}
        refreshControl={
          <RefreshControl refreshing={refreshing} onRefresh={() => { setRefreshing(true); load(); }} tintColor="#ff6b9d" />
        }
        ListEmptyComponent={
          <Text style={styles.empty}>Aún no tienes conexiones. Busca personas y envía solicitudes.</Text>
        }
      />
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: '#0f0f13' },
  center: { flex: 1, justifyContent: 'center', alignItems: 'center', backgroundColor: '#0f0f13' },
  section: { color: '#ff6b9d', fontWeight: 'bold', fontSize: 14, marginBottom: 10, marginTop: 8 },
  card: {
    flexDirection: 'row', alignItems: 'center', backgroundColor: '#1a1a22',
    borderRadius: 14, padding: 14, marginBottom: 10, borderWidth: 1, borderColor: '#2a2a35'
  },
  avatar: {
    width: 48, height: 48, borderRadius: 24, backgroundColor: '#ff6b9d',
    justifyContent: 'center', alignItems: 'center', marginRight: 12, overflow: 'hidden'
  },
  avatarImg: { width: 48, height: 48 },
  avatarLetter: { color: '#fff', fontWeight: 'bold', fontSize: 18 },
  name: { color: '#e8e8ed', fontWeight: '600', fontSize: 15 },
  meta: { color: '#a0a0b0', fontSize: 12, marginTop: 2 },
  status: { color: '#888', fontSize: 11, marginTop: 4 },
  acceptBtn: {
    backgroundColor: '#ff6b9d', borderRadius: 8, paddingVertical: 6, paddingHorizontal: 12, marginBottom: 6
  },
  acceptText: { color: '#fff', fontWeight: '600', fontSize: 12 },
  rejectBtn: { backgroundColor: '#2a2a35', borderRadius: 8, paddingVertical: 6, paddingHorizontal: 12 },
  rejectText: { color: '#a0a0b0', fontSize: 12 },
  msgBtn: {
    backgroundColor: '#2a2a35', borderRadius: 8, paddingVertical: 8, paddingHorizontal: 12
  },
  msgText: { color: '#ff6b9d', fontWeight: '600', fontSize: 12 },
  empty: { color: '#a0a0b0', textAlign: 'center', marginTop: 40 },
});
