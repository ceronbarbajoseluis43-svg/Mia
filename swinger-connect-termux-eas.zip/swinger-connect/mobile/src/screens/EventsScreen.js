import React, { useState, useCallback } from 'react';
import {
  View, Text, FlatList, TouchableOpacity, StyleSheet, TextInput,
  Modal, Alert, ActivityIndicator, RefreshControl, ScrollView
} from 'react-native';
import { useFocusEffect } from '@react-navigation/native';
import { eventsAPI } from '../services/api';

export default function EventsScreen() {
  const [events, setEvents] = useState([]);
  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);
  const [modalVisible, setModalVisible] = useState(false);
  const [creating, setCreating] = useState(false);
  const [form, setForm] = useState({
    title: '',
    description: '',
    location: '',
    city: '',
    startDate: '',
  });

  const load = useCallback(async () => {
    try {
      const { data } = await eventsAPI.list({ upcoming: 'true' });
      setEvents(data.events || []);
    } catch (e) {
      console.log(e);
    } finally {
      setLoading(false);
      setRefreshing(false);
    }
  }, []);

  useFocusEffect(useCallback(() => { load(); }, [load]));

  const createEvent = async () => {
    if (!form.title.trim() || !form.startDate.trim()) {
      Alert.alert('Error', 'Título y fecha de inicio son obligatorios\nFormato fecha: 2026-10-15T20:00:00');
      return;
    }
    setCreating(true);
    try {
      await eventsAPI.create({
        ...form,
        startDate: new Date(form.startDate).toISOString(),
      });
      setModalVisible(false);
      setForm({ title: '', description: '', location: '', city: '', startDate: '' });
      load();
      Alert.alert('Éxito', 'Evento creado');
    } catch (err) {
      Alert.alert('Error', err.response?.data?.error || 'No se pudo crear');
    } finally {
      setCreating(false);
    }
  };

  const attend = async (id, status) => {
    try {
      await eventsAPI.attend(id, status);
      load();
    } catch (err) {
      Alert.alert('Error', 'No se pudo actualizar');
    }
  };

  const renderEvent = ({ item }) => (
    <View style={styles.card}>
      <Text style={styles.eventTitle}>{item.title}</Text>
      <Text style={styles.meta}>
        📅 {new Date(item.startDate).toLocaleString('es')}
      </Text>
      {item.city ? <Text style={styles.meta}>📍 {item.city}{item.location ? ` · ${item.location}` : ''}</Text> : null}
      {item.description ? <Text style={styles.desc} numberOfLines={3}>{item.description}</Text> : null}
      <Text style={styles.creator}>
        Por {item.creator?.displayName} · {item.attendeesCount || 0} interesados
      </Text>

      <View style={styles.actions}>
        <TouchableOpacity
          style={[styles.btn, item.myStatus === 'going' && styles.btnActive]}
          onPress={() => attend(item.id, 'going')}
        >
          <Text style={styles.btnText}>{item.myStatus === 'going' ? '✓ Voy' : 'Voy'}</Text>
        </TouchableOpacity>
        <TouchableOpacity
          style={[styles.btn, item.myStatus === 'interested' && styles.btnActive]}
          onPress={() => attend(item.id, 'interested')}
        >
          <Text style={styles.btnText}>{item.myStatus === 'interested' ? '✓ Interesado' : 'Me interesa'}</Text>
        </TouchableOpacity>
      </View>
    </View>
  );

  if (loading) {
    return (
      <View style={styles.center}>
        <ActivityIndicator size="large" color="#ff6b9d" />
      </View>
    );
  }

  return (
    <View style={styles.container}>
      <TouchableOpacity style={styles.createBtn} onPress={() => setModalVisible(true)}>
        <Text style={styles.createText}>+ Crear evento</Text>
      </TouchableOpacity>

      <FlatList
        data={events}
        keyExtractor={(item) => item.id}
        renderItem={renderEvent}
        contentContainerStyle={{ padding: 16, paddingBottom: 40 }}
        refreshControl={
          <RefreshControl refreshing={refreshing} onRefresh={() => { setRefreshing(true); load(); }} tintColor="#ff6b9d" />
        }
        ListEmptyComponent={<Text style={styles.empty}>No hay eventos próximos. ¡Crea el primero!</Text>}
      />

      <Modal visible={modalVisible} animationType="slide" transparent>
        <View style={styles.modalOverlay}>
          <ScrollView style={styles.modalContent} contentContainerStyle={{ padding: 20 }}>
            <Text style={styles.modalTitle}>Nuevo evento</Text>

            <Text style={styles.label}>Título *</Text>
            <TextInput style={styles.input} value={form.title} onChangeText={v => setForm({ ...form, title: v })} placeholder="Fiesta privada..." placeholderTextColor="#666" />

            <Text style={styles.label}>Descripción</Text>
            <TextInput style={[styles.input, { height: 80 }]} value={form.description} onChangeText={v => setForm({ ...form, description: v })} multiline placeholderTextColor="#666" />

            <Text style={styles.label}>Fecha inicio * (AAAA-MM-DDTHH:MM:SS)</Text>
            <TextInput style={styles.input} value={form.startDate} onChangeText={v => setForm({ ...form, startDate: v })} placeholder="2026-10-20T21:00:00" placeholderTextColor="#666" />

            <Text style={styles.label}>Ciudad</Text>
            <TextInput style={styles.input} value={form.city} onChangeText={v => setForm({ ...form, city: v })} placeholderTextColor="#666" />

            <Text style={styles.label}>Lugar / Dirección</Text>
            <TextInput style={styles.input} value={form.location} onChangeText={v => setForm({ ...form, location: v })} placeholderTextColor="#666" />

            <TouchableOpacity style={[styles.saveBtn, creating && { opacity: 0.6 }]} onPress={createEvent} disabled={creating}>
              {creating ? <ActivityIndicator color="#fff" /> : <Text style={styles.saveText}>Crear evento</Text>}
            </TouchableOpacity>
            <TouchableOpacity style={styles.cancelBtn} onPress={() => setModalVisible(false)}>
              <Text style={styles.cancelText}>Cancelar</Text>
            </TouchableOpacity>
          </ScrollView>
        </View>
      </Modal>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: '#0f0f13' },
  center: { flex: 1, justifyContent: 'center', alignItems: 'center', backgroundColor: '#0f0f13' },
  createBtn: {
    margin: 16, marginBottom: 0, backgroundColor: '#ff6b9d', borderRadius: 12,
    padding: 14, alignItems: 'center'
  },
  createText: { color: '#fff', fontWeight: 'bold', fontSize: 15 },
  card: {
    backgroundColor: '#1a1a22', borderRadius: 14, padding: 16, marginBottom: 12,
    borderWidth: 1, borderColor: '#2a2a35'
  },
  eventTitle: { color: '#e8e8ed', fontSize: 17, fontWeight: 'bold', marginBottom: 6 },
  meta: { color: '#a0a0b0', fontSize: 13, marginBottom: 2 },
  desc: { color: '#c0c0c8', fontSize: 14, marginTop: 8, lineHeight: 20 },
  creator: { color: '#888', fontSize: 12, marginTop: 10 },
  actions: { flexDirection: 'row', gap: 10, marginTop: 12 },
  btn: {
    flex: 1, backgroundColor: '#2a2a35', borderRadius: 10, paddingVertical: 10, alignItems: 'center'
  },
  btnActive: { backgroundColor: '#ff6b9d' },
  btnText: { color: '#e8e8ed', fontWeight: '600', fontSize: 13 },
  empty: { color: '#a0a0b0', textAlign: 'center', marginTop: 40 },
  modalOverlay: { flex: 1, backgroundColor: 'rgba(0,0,0,0.7)', justifyContent: 'flex-end' },
  modalContent: {
    backgroundColor: '#1a1a22', borderTopLeftRadius: 20, borderTopRightRadius: 20, maxHeight: '85%'
  },
  modalTitle: { color: '#e8e8ed', fontSize: 20, fontWeight: 'bold', marginBottom: 16 },
  label: { color: '#a0a0b0', fontSize: 13, marginBottom: 6, marginTop: 12 },
  input: {
    backgroundColor: '#0f0f13', borderRadius: 10, padding: 14, color: '#e8e8ed',
    borderWidth: 1, borderColor: '#3a3a48'
  },
  saveBtn: {
    backgroundColor: '#ff6b9d', borderRadius: 12, padding: 16, alignItems: 'center', marginTop: 24
  },
  saveText: { color: '#fff', fontWeight: 'bold' },
  cancelBtn: { padding: 16, alignItems: 'center' },
  cancelText: { color: '#a0a0b0' },
});
