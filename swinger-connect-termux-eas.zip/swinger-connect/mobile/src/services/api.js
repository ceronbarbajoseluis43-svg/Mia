import axios from 'axios';
import AsyncStorage from '@react-native-async-storage/async-storage';

// Configura EXPO_PUBLIC_API_URL en .env o en el entorno de EAS.
// No uses una IP local para una APK que se distribuirá por Internet.
const API_BASE_URL = process.env.EXPO_PUBLIC_API_URL || 'https://CAMBIA-ESTA-URL/api';
const SERVER_BASE = API_BASE_URL.replace('/api', '');

const api = axios.create({
  baseURL: API_BASE_URL,
  timeout: 30000,
  headers: { 'Content-Type': 'application/json' },
});

api.interceptors.request.use(async (config) => {
  const token = await AsyncStorage.getItem('token');
  if (token) {
    config.headers.Authorization = `Bearer ${token}`;
  }
  return config;
});

export const getMediaUrl = (path) => {
  if (!path) return null;
  if (path.startsWith('http')) return path;
  return `${SERVER_BASE}${path}`;
};

export const authAPI = {
  register: (data) => api.post('/auth/register', data),
  login: (data) => api.post('/auth/login', data),
};

export const usersAPI = {
  me: () => api.get('/users/me'),
  updateMe: (data) => api.put('/users/me', data),
  search: (params) => api.get('/users/search', { params }),
  getById: (id) => api.get(`/users/${id}`),
};

export const postsAPI = {
  create: (data) => api.post('/posts', data),
  feed: () => api.get('/posts/feed'),
  myPosts: () => api.get('/posts/me'),
  delete: (id) => api.delete(`/posts/${id}`),
};

export const friendshipsAPI = {
  request: (userId) => api.post(`/friendships/request/${userId}`),
  accept: (id) => api.post(`/friendships/accept/${id}`),
  reject: (id) => api.post(`/friendships/reject/${id}`),
  list: () => api.get('/friendships'),
};

export const messagesAPI = {
  send: (data) => api.post('/messages', data),
  conversation: (userId) => api.get(`/messages/with/${userId}`),
  list: () => api.get('/messages'),
};

export const eventsAPI = {
  list: (params) => api.get('/events', { params }),
  get: (id) => api.get(`/events/${id}`),
  create: (data) => api.post('/events', data),
  attend: (id, status) => api.post(`/events/${id}/attend`, { status }),
  delete: (id) => api.delete(`/events/${id}`),
};

export const uploadAPI = {
  upload: async (uri, mimeType = 'image/jpeg') => {
    const token = await AsyncStorage.getItem('token');
    const formData = new FormData();
    const filename = uri.split('/').pop() || `file_${Date.now()}.jpg`;
    const match = /\.(\w+)$/.exec(filename);
    const type = mimeType || (match ? `image/${match[1]}` : 'image/jpeg');

    formData.append('file', {
      uri,
      name: filename,
      type,
    });

    const response = await fetch(`${API_BASE_URL}/upload`, {
      method: 'POST',
      headers: {
        Authorization: `Bearer ${token}`,
        'Content-Type': 'multipart/form-data',
      },
      body: formData,
    });

    if (!response.ok) {
      const err = await response.json().catch(() => ({}));
      throw new Error(err.error || 'Error al subir archivo');
    }
    return response.json();
  },
};

export default api;
