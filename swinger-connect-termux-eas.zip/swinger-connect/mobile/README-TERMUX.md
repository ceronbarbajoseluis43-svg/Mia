# SwingerConnect Mobile — compilación desde Termux/GitHub

## 1. Instalar Node, Git y EAS en Termux

```bash
pkg update -y
pkg install nodejs git unzip -y
npm install -g eas-cli
```

## 2. Instalar dependencias

Desde la carpeta `mobile`:

```bash
npm install
```

## 3. Configurar el backend

Copia `.env.example` a `.env` y cambia la URL:

```bash
cp .env.example .env
nano .env
```

Debe quedar, por ejemplo:

```text
EXPO_PUBLIC_API_URL=https://TU-DOMINIO/api
```

No uses `192.168.x.x` para una APK que deba funcionar desde Internet.

## 4. Iniciar sesión en Expo/EAS

```bash
eas login
```

## 5. Generar APK de prueba

```bash
eas build -p android --profile preview
```

EAS mostrará un enlace para descargar el APK cuando termine.

## 6. APK de producción

```bash
eas build -p android --profile production
```

## Importante

Este proyecto contiene el backend en `../backend`, pero la APK necesita que ese backend esté desplegado en una URL accesible desde Internet. La configuración local anterior (`192.168.1.100:4000`) fue eliminada de la app móvil para evitar que la APK quede apuntando a una red doméstica.
