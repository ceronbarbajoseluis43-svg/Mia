# SwingerConnect Mobile (Expo) – Versión completa

## Requisitos
- Node.js LTS
- App **Expo Go** en Android: https://play.google.com/store/apps/details?id=host.exp.exponent

## Pasos para probar en Android

1. Arranca el **backend** en el ordenador:
```bash
cd backend
npm install
npx prisma generate
npx prisma db push
npm run dev
```

2. Averigua tu IP local (ej: 192.168.1.15)

3. Edita `src/services/api.js` y cambia:
```js
const API_BASE_URL = 'http://192.168.1.15:4000/api';
```

4. Arranca la app:
```bash
cd mobile
npm install
npx expo start
```

5. Abre Expo Go → escanea el QR

## Pantallas incluidas
- Login / Registro (18+)
- Feed (publicar texto + fotos + videos)
- Buscar personas + conectar
- Eventos (crear y apuntarse)
- Chats / Mensajes con media
- Amigos (solicitudes, aceptar, chatear)
- Perfil + Editar perfil (foto, bio, preferencias)

## Solución de problemas
- Network Error → revisa la IP y que el backend esté corriendo
- Mismo WiFi obligatorio
- Reinicia con `r` en la terminal de Expo
