import React, { useState, useEffect } from 'react';
import { NavigationContainer, DarkTheme } from '@react-navigation/native';
import { createNativeStackNavigator } from '@react-navigation/native-stack';
import { StatusBar } from 'expo-status-bar';
import { View, Text, ActivityIndicator, StyleSheet, TouchableOpacity } from 'react-native';
import AsyncStorage from '@react-native-async-storage/async-storage';

import LoginScreen from './src/screens/LoginScreen';
import RegisterScreen from './src/screens/RegisterScreen';
import FeedScreen from './src/screens/FeedScreen';
import SearchScreen from './src/screens/SearchScreen';
import ProfileScreen from './src/screens/ProfileScreen';
import EditProfileScreen from './src/screens/EditProfileScreen';
import MessagesScreen from './src/screens/MessagesScreen';
import ChatScreen from './src/screens/ChatScreen';
import EventsScreen from './src/screens/EventsScreen';
import FriendsScreen from './src/screens/FriendsScreen';
import { usersAPI } from './src/services/api';

const Stack = createNativeStackNavigator();

const MyTheme = {
  ...DarkTheme,
  colors: {
    ...DarkTheme.colors,
    background: '#0f0f13',
    card: '#1a1a22',
    primary: '#ff6b9d',
    text: '#e8e8ed',
    border: '#2a2a35',
  },
};

function MainTabs({ user, onLogout, onUserUpdate }) {
  const [tab, setTab] = useState('feed');

  const tabs = [
    { key: 'feed', label: 'Feed' },
    { key: 'search', label: 'Buscar' },
    { key: 'events', label: 'Eventos' },
    { key: 'messages', label: 'Chats' },
    { key: 'friends', label: 'Amigos' },
    { key: 'profile', label: 'Perfil' },
  ];

  return (
    <View style={{ flex: 1, backgroundColor: '#0f0f13' }}>
      <View style={{ flex: 1 }}>
        {tab === 'feed' && <FeedScreen />}
        {tab === 'search' && <SearchScreen />}
        {tab === 'events' && <EventsScreen />}
        {tab === 'messages' && <MessagesScreenWrapper />}
        {tab === 'friends' && <FriendsScreenWrapper />}
        {tab === 'profile' && (
          <ProfileScreenWrapper user={user} onLogout={onLogout} />
        )}
      </View>

      <View style={styles.tabBar}>
        {tabs.map(t => (
          <TouchableOpacity key={t.key} style={styles.tabButton} onPress={() => setTab(t.key)}>
            <Text style={[styles.tabText, tab === t.key && styles.tabTextActive]}>
              {t.label}
            </Text>
          </TouchableOpacity>
        ))}
      </View>
    </View>
  );
}

// Wrappers para poder usar navigation en tabs
function MessagesScreenWrapper() {
  const { navigate } = require('@react-navigation/native').useNavigation();
  return <MessagesScreen navigation={{ navigate }} />;
}

function FriendsScreenWrapper() {
  const { navigate } = require('@react-navigation/native').useNavigation();
  return <FriendsScreen navigation={{ navigate }} />;
}

function ProfileScreenWrapper({ user, onLogout }) {
  const { navigate } = require('@react-navigation/native').useNavigation();
  return <ProfileScreen user={user} onLogout={onLogout} navigation={{ navigate }} />;
}

export default function App() {
  const [user, setUser] = useState(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    checkAuth();
  }, []);

  const checkAuth = async () => {
    try {
      const token = await AsyncStorage.getItem('token');
      if (token) {
        const { data } = await usersAPI.me();
        setUser(data.user);
      }
    } catch (err) {
      await AsyncStorage.removeItem('token');
    } finally {
      setLoading(false);
    }
  };

  const handleLogin = (userData) => setUser(userData);
  const handleLogout = () => setUser(null);
  const handleUserUpdate = (updated) => setUser(prev => ({ ...prev, ...updated }));

  if (loading) {
    return (
      <View style={styles.loading}>
        <ActivityIndicator size="large" color="#ff6b9d" />
        <Text style={{ color: '#a0a0b0', marginTop: 12 }}>Cargando...</Text>
      </View>
    );
  }

  return (
    <NavigationContainer theme={MyTheme}>
      <StatusBar style="light" />
      <Stack.Navigator
        screenOptions={{
          headerStyle: { backgroundColor: '#1a1a22' },
          headerTintColor: '#ff6b9d',
          headerTitleStyle: { color: '#e8e8ed' },
          contentStyle: { backgroundColor: '#0f0f13' },
        }}
      >
        {user ? (
          <>
            <Stack.Screen name="Main" options={{ headerShown: false }}>
              {() => (
                <MainTabs
                  user={user}
                  onLogout={handleLogout}
                  onUserUpdate={handleUserUpdate}
                />
              )}
            </Stack.Screen>
            <Stack.Screen name="EditProfile" options={{ title: 'Editar perfil' }}>
              {(props) => (
                <EditProfileScreen
                  {...props}
                  user={user}
                  onUpdate={handleUserUpdate}
                />
              )}
            </Stack.Screen>
            <Stack.Screen
              name="Chat"
              component={ChatScreen}
              options={({ route }) => ({ title: route.params?.userName || 'Chat' })}
            />
          </>
        ) : (
          <>
            <Stack.Screen name="Login" options={{ headerShown: false }}>
              {(props) => <LoginScreen {...props} onLogin={handleLogin} />}
            </Stack.Screen>
            <Stack.Screen name="Register" options={{ headerShown: false }}>
              {(props) => <RegisterScreen {...props} onLogin={handleLogin} />}
            </Stack.Screen>
          </>
        )}
      </Stack.Navigator>
    </NavigationContainer>
  );
}

const styles = StyleSheet.create({
  loading: {
    flex: 1, backgroundColor: '#0f0f13', justifyContent: 'center', alignItems: 'center'
  },
  tabBar: {
    flexDirection: 'row', backgroundColor: '#1a1a22',
    borderTopWidth: 1, borderTopColor: '#2a2a35',
    paddingBottom: 18, paddingTop: 10
  },
  tabButton: { flex: 1, alignItems: 'center' },
  tabText: { color: '#a0a0b0', fontSize: 11, fontWeight: '500' },
  tabTextActive: { color: '#ff6b9d', fontWeight: 'bold' },
});
